export interface Address {
  line1: string;
  city: string;
  postalCode: string;
  country: string; // ISO 3166-1 alpha-2
}

export interface OrderItem {
  sku: string;
  quantity: number;
  unitPrice: number;
}

export type OrderStatus = 'NEW' | 'PAID' | 'SHIPPED';

export interface Order {
  id: string;
  customerId: string;
  customerEmail: string;
  items: OrderItem[];
  shippingAddress: Address;
  status: OrderStatus;
  createdAt: string;
}
