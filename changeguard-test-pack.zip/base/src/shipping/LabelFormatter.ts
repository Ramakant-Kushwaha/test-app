// Shipping keeps its own copy of the address contract.
export interface ShippingAddress {
  line1: string;
  city: string;
  postalCode: string;
  country: string;
}

export function formatLabel(orderId: string, address: ShippingAddress): string {
  const postal = address.postalCode.trim().toUpperCase();
  return [orderId, address.line1, `${postal} ${address.city}`, address.country].join('\n');
}
