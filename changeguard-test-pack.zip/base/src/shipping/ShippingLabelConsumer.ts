import { bus } from '../events/bus';
import { formatLabel, ShippingAddress } from './LabelFormatter';

interface AddressEvent {
  orderId: string;
  shippingAddress: ShippingAddress;
}

export const labels: string[] = [];

export function resetLabels(): void {
  labels.length = 0;
}

function onAddressEvent(raw: string): void {
  const event = JSON.parse(raw) as AddressEvent;
  labels.push(formatLabel(event.orderId, event.shippingAddress));
}

bus.on('order.created', onAddressEvent);
bus.on('order.address_changed', onAddressEvent);
