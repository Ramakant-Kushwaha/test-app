import { bus } from '../events/bus';

// Inventory keeps its own copy of the event contract (it is deployed separately).
interface OrderCreatedEvent {
  orderId: string;
  items: { sku: string; quantity: number }[];
}

export const reservations = new Map<string, number>();

export function resetInventory(): void {
  reservations.clear();
}

bus.on('order.created', (raw: string) => {
  const event = JSON.parse(raw) as OrderCreatedEvent;
  for (const item of event.items) {
    reservations.set(item.sku, (reservations.get(item.sku) ?? 0) + item.quantity);
  }
});
