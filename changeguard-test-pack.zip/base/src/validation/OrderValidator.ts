import { Address, OrderItem } from '../domain/Order';

export class ValidationError extends Error {
  constructor(public readonly code: string, message: string) {
    super(message);
    this.name = 'ValidationError';
  }
}

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const POSTAL_PATTERN = /^[A-Z0-9][A-Z0-9 -]{1,8}[A-Z0-9]$/i;
const COUNTRY_PATTERN = /^[A-Z]{2}$/;

export function validateEmail(email: string): void {
  if (!EMAIL_PATTERN.test(email)) {
    throw new ValidationError('INVALID_EMAIL', 'customer email is not valid');
  }
}

export function validateAddress(address: Address): void {
  if (!address.line1.trim() || !address.city.trim()) {
    throw new ValidationError('INVALID_ADDRESS', 'line1 and city are required');
  }
  if (!COUNTRY_PATTERN.test(address.country)) {
    throw new ValidationError('INVALID_COUNTRY', 'country must be a 2-letter ISO code');
  }
  if (!POSTAL_PATTERN.test(address.postalCode)) {
    throw new ValidationError('INVALID_POSTAL_CODE', 'postal code is not valid');
  }
}

export function validateItems(items: OrderItem[]): void {
  if (items.length === 0) {
    throw new ValidationError('NO_ITEMS', 'an order needs at least one item');
  }
  for (const item of items) {
    if (!Number.isInteger(item.quantity) || item.quantity <= 0) {
      throw new ValidationError('INVALID_QUANTITY', `invalid quantity for ${item.sku}`);
    }
    if (item.unitPrice <= 0) {
      throw new ValidationError('INVALID_PRICE', `invalid unit price for ${item.sku}`);
    }
  }
}
