import { EventEmitter } from 'events';

// In-process event bus. emit() is synchronous: a listener that throws makes emit() throw.
export const bus = new EventEmitter();
