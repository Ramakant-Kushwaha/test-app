// Application entry: importing the consumers registers their event listeners.
import './inventory/InventoryConsumer';
import './shipping/ShippingLabelConsumer';
import './notifications/EmailConsumer';

export { createOrder, updateShippingAddress } from './orders/OrderService';
export { totalsBySku } from './reports/SalesReport';
