import { bus } from '../events/bus';

// Notifications keep their own copy of the event contract.
interface OrderCreatedEvent {
  orderId: string;
  customerEmail: string;
}

export const outbox: { to: string; subject: string; body: string }[] = [];

export function resetOutbox(): void {
  outbox.length = 0;
}

bus.on('order.created', (raw: string) => {
  const event = JSON.parse(raw) as OrderCreatedEvent;
  outbox.push({
    to: event.customerEmail.toLowerCase(),
    subject: `Order ${event.orderId} received`,
    body: `Thank you for your order ${event.orderId}.`,
  });
});
