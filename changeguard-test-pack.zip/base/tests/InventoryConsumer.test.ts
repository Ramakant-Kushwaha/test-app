import { bus } from '../src/events/bus';
import { reservations, resetInventory } from '../src/inventory/InventoryConsumer';

const event = (items: { sku: string; quantity: number }[]) => JSON.stringify({ orderId: 'ORD-1', items });

describe('InventoryConsumer', () => {
  beforeEach(() => resetInventory());

  test('reserves the ordered quantity per sku', () => {
    bus.emit('order.created', event([{ sku: 'SKU-A', quantity: 3 }]));
    expect(reservations.get('SKU-A')).toBe(3);
  });

  test('adds up reservations across orders', () => {
    bus.emit('order.created', event([{ sku: 'SKU-A', quantity: 1 }]));
    bus.emit('order.created', event([{ sku: 'SKU-A', quantity: 4 }]));
    expect(reservations.get('SKU-A')).toBe(5);
  });
});
