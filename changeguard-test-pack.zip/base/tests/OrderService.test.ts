import { bus } from '../src/events/bus';
import { auditLog, createOrder, resetOrders, updateShippingAddress } from '../src/orders/OrderService';
import { orderRepository } from '../src/repository/OrderRepository';
import { validInput } from './helpers';

describe('OrderService', () => {
  beforeEach(() => {
    resetOrders();
    bus.removeAllListeners();
  });

  test('creates an order with a sequential id and status NEW', () => {
    const order = createOrder(validInput());
    expect(order.id).toBe('ORD-00001');
    expect(order.status).toBe('NEW');
  });

  test('saves the order in the repository', () => {
    const order = createOrder(validInput());
    expect(orderRepository.findById(order.id)?.customerId).toBe('C-100');
  });

  test('publishes one order.created event for the order', () => {
    const events: string[] = [];
    bus.on('order.created', (raw: string) => events.push(raw));
    const order = createOrder(validInput());
    expect(events).toHaveLength(1);
    const payload = JSON.parse(events[0]);
    expect(payload.orderId).toBe(order.id);
    expect(payload.items).toHaveLength(2);
  });

  test('writes an audit entry', () => {
    const order = createOrder(validInput());
    expect(auditLog).toEqual([{ orderId: order.id, action: 'created', at: order.createdAt }]);
  });

  test('publishes order.address_changed when the address is updated', () => {
    const events: string[] = [];
    bus.on('order.address_changed', (raw: string) => events.push(raw));
    const order = createOrder(validInput());
    updateShippingAddress(order.id, { line1: '5 Park St', city: 'Kolkata', postalCode: '700016', country: 'IN' });
    expect(events).toHaveLength(1);
    expect(JSON.parse(events[0]).shippingAddress.city).toBe('Kolkata');
  });

  test('throws for an unknown order', () => {
    expect(() =>
      updateShippingAddress('ORD-99999', { line1: 'x', city: 'y', postalCode: '12345', country: 'IN' }),
    ).toThrow('not found');
  });
});
