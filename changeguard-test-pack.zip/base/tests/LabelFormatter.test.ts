import { formatLabel } from '../src/shipping/LabelFormatter';

const address = { line1: '12 MG Road', city: 'Bengaluru', postalCode: '560001', country: 'IN' };

describe('LabelFormatter', () => {
  test('formats a four-line label', () => {
    expect(formatLabel('ORD-1', address).split('\n')).toHaveLength(4);
  });

  test('uppercases the postal code', () => {
    expect(formatLabel('ORD-1', { ...address, postalCode: 'sw1a 1aa', country: 'GB' })).toContain('SW1A 1AA');
  });

  test('trims the postal code', () => {
    expect(formatLabel('ORD-1', { ...address, postalCode: ' 560001 ' })).toContain('560001 Bengaluru');
  });
});
