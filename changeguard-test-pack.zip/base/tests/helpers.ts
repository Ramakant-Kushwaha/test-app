import { CreateOrderInput } from '../src/orders/OrderService';

export function validInput(overrides: Partial<CreateOrderInput> = {}): CreateOrderInput {
  return {
    customerId: 'C-100',
    customerEmail: 'Asha.Rao@example.com',
    items: [
      { sku: 'SKU-RED-MUG', quantity: 2, unitPrice: 12.5 },
      { sku: 'SKU-BLUE-CAP', quantity: 1, unitPrice: 20 },
    ],
    shippingAddress: { line1: '12 MG Road', city: 'Bengaluru', postalCode: '560001', country: 'IN' },
    ...overrides,
  };
}
