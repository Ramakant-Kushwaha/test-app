import { totalsBySku } from '../src/reports/SalesReport';
import { Order } from '../src/domain/Order';

const order = (id: string, items: Order['items']): Order => ({
  id,
  customerId: 'C-1',
  customerEmail: 'a@b.com',
  items,
  shippingAddress: { line1: 'x', city: 'y', postalCode: '12345', country: 'IN' },
  status: 'NEW',
  createdAt: '2026-01-01T00:00:00.000Z',
});

describe('SalesReport', () => {
  test('adds quantity and revenue per sku', () => {
    const totals = totalsBySku([
      order('1', [{ sku: 'A', quantity: 2, unitPrice: 5 }]),
      order('2', [{ sku: 'A', quantity: 1, unitPrice: 5 }]),
    ]);
    expect(totals).toEqual([{ sku: 'A', quantity: 3, revenue: 15 }]);
  });

  test('sorts by revenue, highest first', () => {
    const totals = totalsBySku([order('1', [{ sku: 'A', quantity: 1, unitPrice: 1 }, { sku: 'B', quantity: 1, unitPrice: 9 }])]);
    expect(totals.map((t) => t.sku)).toEqual(['B', 'A']);
  });
});
