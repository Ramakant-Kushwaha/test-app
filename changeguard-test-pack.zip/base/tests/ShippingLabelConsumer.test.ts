import { bus } from '../src/events/bus';
import { labels, resetLabels } from '../src/shipping/ShippingLabelConsumer';

describe('ShippingLabelConsumer', () => {
  beforeEach(() => resetLabels());

  test('creates a label when an address changes', () => {
    bus.emit(
      'order.address_changed',
      JSON.stringify({
        orderId: 'ORD-7',
        shippingAddress: { line1: '5 Park St', city: 'Kolkata', postalCode: '700016', country: 'IN' },
      }),
    );
    expect(labels).toHaveLength(1);
    expect(labels[0]).toContain('700016 Kolkata');
  });
});
