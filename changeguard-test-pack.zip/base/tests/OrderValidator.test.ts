import { validateAddress, validateEmail, validateItems, ValidationError } from '../src/validation/OrderValidator';

const address = { line1: '1 Main St', city: 'Pune', postalCode: '411001', country: 'IN' };

describe('OrderValidator', () => {
  test('accepts a valid email, address and items', () => {
    expect(() => validateEmail('a@b.com')).not.toThrow();
    expect(() => validateAddress(address)).not.toThrow();
    expect(() => validateItems([{ sku: 'S', quantity: 1, unitPrice: 1 }])).not.toThrow();
  });

  test('rejects an invalid email', () => {
    expect(() => validateEmail('not-an-email')).toThrow(ValidationError);
  });

  test('rejects an order without items', () => {
    expect(() => validateItems([])).toThrow('at least one item');
  });

  test('rejects a zero quantity', () => {
    expect(() => validateItems([{ sku: 'S', quantity: 0, unitPrice: 1 }])).toThrow('invalid quantity');
  });

  test('rejects a country that is not a 2-letter code', () => {
    expect(() => validateAddress({ ...address, country: 'India' })).toThrow('2-letter');
  });

  test('rejects an invalid postal code', () => {
    expect(() => validateAddress({ ...address, postalCode: '!!' })).toThrow('postal code');
  });

  test('rejects a blank city', () => {
    expect(() => validateAddress({ ...address, city: '  ' })).toThrow('required');
  });
});
