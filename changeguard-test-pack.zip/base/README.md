# order-fulfillment-service

Handles orders end to end: validation, persistence, and events consumed by inventory (stock reservations),
shipping (labels) and notifications (confirmation emails), plus a sales report.

Each consumer keeps its own copy of the event contract, because in production they are deployed separately.

## Run
npm ci
npm run typecheck
npm test
