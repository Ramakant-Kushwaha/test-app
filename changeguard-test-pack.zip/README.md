# ChangeGuard test pack — order-fulfillment-service

A second, realistic repository to test ChangeGuard on changes the agents have never seen.

- `base/` — the repository (TypeScript, Node 20, Jest + ts-jest; 23 passing tests). Different domain from the pricing fixture.
- `scenarios/` — 8 seeded commits (5 with a ticket, 1 without, 1 docs-only, 1 opt-out). Each keeps typecheck and the existing tests green.
- `tickets/` — requirements for ORD-201…205 (also in each commit body).
- `answer-key/` — expected results + reference proofs. **Keep it outside the ChangeGuard workspace.**

## 1. Put the pack outside the workspace
Unzip to `C:\D\changeguard-test-pack` (NOT inside `thunderbobs-frontend`, so agents and Bob never see the answer key).

## 2. Create the repository (Git Bash)
    cd /c/D/changeguard-test-pack
    ./setup-test-repo.sh /c/D/thunderbobs-frontend/fixture/order-fulfillment-service
This creates `main` (tag `base-v1`), installs dependencies and checks the 23 tests pass.
Copy the tickets so ChangeGuard can find them:
    cp tickets/*.md /c/D/thunderbobs-frontend/tickets/

## 3. Point ChangeGuard at it
ChangeGuard is currently wired to `fixture/target-enterprise-app` (repo_id product-pricing-service). Give Bob the prompt
in section 6 once, so the target repository becomes a setting. Then install the hook for the new repo:
    cd /c/D/thunderbobs-frontend && scripts/install-hook.sh fixture/order-fulfillment-service

## 4. Run a scenario (this commits → the hook triggers ChangeGuard)
    cd /c/D/changeguard-test-pack
    ./run-scenario.sh list
    ./run-scenario.sh ORD-201 /c/D/thunderbobs-frontend/fixture/order-fulfillment-service
Watch Mission Control and Bob. Compare with `answer-key/ANSWER_KEY.md` and fill in its score sheet.

## 5. Reset and repeat
    ./reset-scenario.sh ORD-201 /c/D/thunderbobs-frontend/fixture/order-fulfillment-service   # or: all
Suggested order: ORD-201 → ORD-205 (false-positive check) → GUEST → DOCS → SKIP → ORD-202 → ORD-203 → ORD-204.

Optional: push to GitLab as its own project (`git remote add origin <url>; git push -u origin main --tags`) to test the MR flow later.

## 6. Prompt for Bob (once): make the target repository configurable
    Make ChangeGuard's target repository configurable instead of hard-coded to fixture/target-enterprise-app.
    Windows + Git Bash. Don't change approval, executor or verdict logic. All tests must keep passing.
    - New settings in services/changeguard-tools/.env and services/backend/.env: TARGET_REPO (path of the repo,
      e.g. fixture/order-fulfillment-service) and REPO_ID (e.g. order-fulfillment-service). Defaults keep today's
      behaviour (fixture/target-enterprise-app, product-pricing-service).
    - scripts/make-demo-work.sh takes the target from TARGET_REPO/REPO_ID, writes the marker with that repo_id, and
      creates fixture/demo-work from it; config checks (marker, origin) use the same values.
    - The git hook, live inputs (merge-base with main, ticket, requirement) and reset work for any target repo.
    - Nothing in tools, runtime or agent instructions may depend on file names of a specific repo.
    - Switch to fixture/order-fulfillment-service, recreate demo-work, run all suites, then make one commit on a new
      branch in that repo and show that a run starts and the agents analyse it. Document the switch in README.
