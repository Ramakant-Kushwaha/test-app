import { Order } from '../domain/Order';

export interface SkuTotal {
  sku: string;
  quantity: number;
  revenue: number;
}

export function totalsBySku(orders: Order[]): SkuTotal[] {
  const totalsMap = new Map<string, SkuTotal>();
  for (const order of orders) {
    for (const item of order.items) {
      const current = totalsMap.get(item.sku) ?? { sku: item.sku, quantity: 0, revenue: 0 };
      current.quantity += item.quantity;
      current.revenue += item.quantity * item.unitPrice;
      totalsMap.set(item.sku, current);
    }
  }
  return [...totalsMap.values()].sort((a, b) => b.revenue - a.revenue);
}
