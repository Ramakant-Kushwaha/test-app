import { Address, Order, OrderItem } from '../domain/Order';
import { validateAddress, validateEmail, validateItems } from '../validation/OrderValidator';
import { orderRepository } from '../repository/OrderRepository';
import { publishAddressChanged, publishOrderCreated } from '../integrations/EventPublisher';

export interface CreateOrderInput {
  customerId: string;
  customerEmail: string;
  items: OrderItem[];
  shippingAddress: Address;
}

export const auditLog: { orderId: string; action: string; at: string }[] = [];

let sequence = 0;

export function resetOrders(): void {
  sequence = 0;
  auditLog.length = 0;
  orderRepository.clear();
}

export function createOrder(input: CreateOrderInput): Order {
  validateEmail(input.customerEmail);
  validateItems(input.items);
  validateAddress(input.shippingAddress);

  sequence += 1;
  const order: Order = {
    id: `ORD-${String(sequence).padStart(5, '0')}`,
    customerId: input.customerId,
    customerEmail: input.customerEmail,
    items: input.items,
    shippingAddress: input.shippingAddress,
    status: 'NEW',
    createdAt: new Date().toISOString(),
  };
  orderRepository.save(order);
  publishOrderCreated(order);
  auditLog.push({ orderId: order.id, action: 'created', at: order.createdAt });
  return order;
}

export function searchOrdersByEmail(email: string): Order[] {
  return orderRepository.findByEmail(email.trim());
}

export function updateShippingAddress(orderId: string, address: Address): Order {
  const order = orderRepository.findById(orderId);
  if (!order) {
    throw new Error(`order ${orderId} not found`);
  }
  validateAddress(address);
  const updated: Order = { ...order, shippingAddress: address };
  orderRepository.save(updated);
  publishAddressChanged(updated);
  auditLog.push({ orderId, action: 'address_changed', at: new Date().toISOString() });
  return updated;
}
