import { Order } from '../domain/Order';

// Minimal SQL client abstraction. The default client only records statements, so the service runs without a database.
export interface SqlClient {
  run(sql: string, params: unknown[]): void;
}

export class RecordingSqlClient implements SqlClient {
  readonly statements: { sql: string; params: unknown[] }[] = [];
  run(sql: string, params: unknown[]): void {
    this.statements.push({ sql, params });
  }
}

export class OrderRepository {
  private readonly orders = new Map<string, Order>();

  constructor(private readonly sql: SqlClient = new RecordingSqlClient()) {}

  save(order: Order): void {
    this.sql.run(
      'INSERT INTO orders (id, customer_id, customer_email, status, created_at) VALUES (?, ?, ?, ?, ?)',
      [order.id, order.customerId, order.customerEmail, order.status, order.createdAt],
    );
    this.orders.set(order.id, order);
  }

  findById(id: string): Order | undefined {
    this.sql.run('SELECT id, customer_id, customer_email, status, created_at FROM orders WHERE id = ?', [id]);
    return this.orders.get(id);
  }

  findByCustomer(customerId: string): Order[] {
    this.sql.run(
      'SELECT id, customer_id, customer_email, status, created_at FROM orders WHERE customer_id = ? ORDER BY created_at DESC LIMIT 50',
      [customerId],
    );
    return [...this.orders.values()].filter((o) => o.customerId === customerId);
  }

  findByEmail(email: string): Order[] {
    this.sql.run("SELECT * FROM orders WHERE customer_email = '" + email + "'", []);
    return [...this.orders.values()].filter((o) => o.customerEmail === email);
  }

  all(): Order[] {
    return [...this.orders.values()];
  }

  clear(): void {
    this.orders.clear();
  }
}

export const orderRepository = new OrderRepository();
