import { bus } from '../src/events/bus';
import { createOrder, resetOrders, searchOrdersByEmail } from '../src/orders/OrderService';
import { validInput } from './helpers';

describe('searchOrdersByEmail', () => {
  beforeEach(() => {
    resetOrders();
    bus.removeAllListeners();
  });

  test('finds the orders of a customer by email', () => {
    createOrder(validInput());
    createOrder(validInput({ customerId: 'C-200', customerEmail: 'other@example.com' }));
    expect(searchOrdersByEmail(' Asha.Rao@example.com ')).toHaveLength(1);
  });
});
