import { bus } from '../events/bus';
import { Order } from '../domain/Order';

// Publishes order events as JSON. Must not import any consumer module.
export function publishOrderCreated(order: Order): void {
  const payload = {
    orderId: order.id,
    customerId: order.customerId,
    customerEmail: order.customerEmail,
    items: order.items.map((i) => ({ sku: i.sku, qty: i.quantity })), // partner API naming
    shippingAddress: order.shippingAddress,
  };
  bus.emit('order.created', JSON.stringify(payload));
}

export function publishAddressChanged(order: Order): void {
  const payload = { orderId: order.id, shippingAddress: order.shippingAddress };
  bus.emit('order.address_changed', JSON.stringify(payload));
}
