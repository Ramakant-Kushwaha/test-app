import { bus } from '../src/events/bus';
import { outbox, resetOutbox } from '../src/notifications/EmailConsumer';

describe('EmailConsumer', () => {
  beforeEach(() => resetOutbox());

  test('sends the confirmation to the lowercased address', () => {
    bus.emit('order.created', JSON.stringify({ orderId: 'ORD-3', customerEmail: 'Asha.Rao@Example.com' }));
    expect(outbox[0].to).toBe('asha.rao@example.com');
  });

  test('includes the gift message when present', () => {
    bus.emit('order.created', JSON.stringify({ orderId: 'ORD-5', customerEmail: 'a@b.com', giftMessage: 'Happy birthday!' }));
    expect(outbox[0].body).toContain('Gift message: Happy birthday!');
  });

  test('mentions the order id in the subject', () => {
    bus.emit('order.created', JSON.stringify({ orderId: 'ORD-4', customerEmail: 'a@b.com' }));
    expect(outbox[0].subject).toBe('Order ORD-4 received');
  });
});
