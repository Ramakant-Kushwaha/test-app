import { Order } from '../domain/Order';
import { OrderRepository, orderRepository } from '../repository/OrderRepository';

export interface SkuTotal {
  sku: string;
  quantity: number;
  revenue: number;
}

export function customerSummary(customerIds: string[], repo: OrderRepository = orderRepository): string {
  let report = '';
  for (const customerId of customerIds) {
    const orders = repo.findByCustomer(customerId);
    let spend = 0;
    for (const order of orders) {
      for (const item of order.items) {
        spend += item.quantity * item.unitPrice;
      }
    }
    report += customerId + ': ' + orders.length + ' orders, ' + spend.toFixed(2) + '\n';
  }
  return report;
}

export function totalsBySku(orders: Order[]): SkuTotal[] {
  const totals = new Map<string, SkuTotal>();
  for (const order of orders) {
    for (const item of order.items) {
      const current = totals.get(item.sku) ?? { sku: item.sku, quantity: 0, revenue: 0 };
      current.quantity += item.quantity;
      current.revenue += item.quantity * item.unitPrice;
      totals.set(item.sku, current);
    }
  }
  return [...totals.values()].sort((a, b) => b.revenue - a.revenue);
}
