import { customerSummary } from '../src/reports/SalesReport';
import { OrderRepository } from '../src/repository/OrderRepository';

describe('customerSummary', () => {
  test('lists order count and spend per customer', () => {
    const repo = new OrderRepository();
    repo.save({
      id: 'ORD-1', customerId: 'C-1', customerEmail: 'a@b.com', status: 'NEW', createdAt: '2026-01-01T00:00:00.000Z',
      items: [{ sku: 'A', quantity: 2, unitPrice: 5 }],
      shippingAddress: { line1: 'x', city: 'y', postalCode: '12345', country: 'IN' },
    });
    expect(customerSummary(['C-1', 'C-2'], repo)).toBe('C-1: 1 orders, 10.00\nC-2: 0 orders, 0.00\n');
  });
});
