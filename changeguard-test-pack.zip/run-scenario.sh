#!/usr/bin/env bash
# Creates a scenario branch from main, applies the scenario's change and COMMITS it — this is what triggers ChangeGuard.
# Usage:  ./run-scenario.sh <ID> <repo folder>        IDs: ORD-201 ORD-202 ORD-203 ORD-204 ORD-205 GUEST DOCS SKIP
#         ./run-scenario.sh list
set -euo pipefail
PACK="$(cd "$(dirname "$0")" && pwd)"
if [ "${1:-list}" = "list" ]; then
  for d in "$PACK"/scenarios/*/; do id=$(basename "$d"); printf '%-8s %-38s %s\n' "$id" "$(cat "$d/BRANCH")" "$(head -1 "$d/COMMIT_MSG")"; done
  exit 0
fi
ID="$1"; REPO="${2:?give the repo folder created by setup-test-repo.sh}"
S="$PACK/scenarios/$ID"; [ -d "$S" ] || { echo "unknown scenario $ID (try: ./run-scenario.sh list)"; exit 1; }
BRANCH="$(cat "$S/BRANCH")"
cd "$REPO"
[ -z "$(git status --porcelain)" ] || { echo "refusing: $REPO has uncommitted changes"; exit 1; }
git rev-parse -q --verify "refs/heads/$BRANCH" >/dev/null && { echo "branch $BRANCH exists; run ./reset-scenario.sh $ID \"$REPO\" first"; exit 1; }

git checkout -q main
git checkout -q -b "$BRANCH"
cp -r "$S/files/." .
echo "Scenario $ID on $BRANCH — checking that typecheck and the EXISTING tests stay green (like CI would)…"
npm run -s typecheck && npx jest --silent
git add -A
git commit -q -F "$S/COMMIT_MSG"      # <- the ChangeGuard post-commit hook fires here
echo "Committed $(git rev-parse --short HEAD) on $BRANCH: $(head -1 "$S/COMMIT_MSG")"
echo "Watch Mission Control / Bob for the ChangeGuard result."
