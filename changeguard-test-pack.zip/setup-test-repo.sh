#!/usr/bin/env bash
# Creates the test repository "order-fulfillment-service" (main branch only, tests green, tag base-v1).
# Usage (Git Bash):  ./setup-test-repo.sh <destination folder>
#   e.g.            ./setup-test-repo.sh /c/D/thunderbobs-frontend/fixture/order-fulfillment-service
set -euo pipefail
PACK="$(cd "$(dirname "$0")" && pwd)"
DEST="${1:?give a destination folder, e.g. /c/D/thunderbobs-frontend/fixture/order-fulfillment-service}"
[ -e "$DEST" ] && { echo "refusing: $DEST already exists (delete it first if you want a fresh copy)"; exit 1; }

mkdir -p "$DEST"
cp -r "$PACK/base/." "$DEST/"
cd "$DEST"
git init -q -b main
git config core.autocrlf false
git config user.name  >/dev/null 2>&1 || git config user.name  "ChangeGuard Tester"
git config user.email >/dev/null 2>&1 || git config user.email "tester@example.com"

echo "Installing dependencies (creates package-lock.json)…"
npm install --no-audit --no-fund --loglevel=error
echo "Typecheck…"; npm run -s typecheck
echo "Tests…";     npx jest --silent

git add -A
git commit -q -m "seed: order-fulfillment-service"
git tag base-v1
echo
echo "Ready: $DEST (branch main, tag base-v1, $(git ls-files | wc -l) files)."
echo "Next: install the ChangeGuard hook for this repo, then run scenarios with ./run-scenario.sh <ID> \"$DEST\""
