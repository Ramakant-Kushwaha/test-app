#!/usr/bin/env bash
# Removes a scenario branch so it can be run again. Usage: ./reset-scenario.sh <ID|all> <repo folder>
set -euo pipefail
PACK="$(cd "$(dirname "$0")" && pwd)"
ID="${1:?ID or all}"; REPO="${2:?repo folder}"
cd "$REPO"
git checkout -q -f main
git clean -fdq -e node_modules
for d in "$PACK"/scenarios/*/; do
  id=$(basename "$d"); [ "$ID" = all ] || [ "$ID" = "$id" ] || continue
  b="$(cat "$d/BRANCH")"
  git rev-parse -q --verify "refs/heads/$b" >/dev/null && git branch -q -D "$b" && echo "deleted $b"
done
echo "On main, clean."
