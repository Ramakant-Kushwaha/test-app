// Reference proof (answer key only — not part of the repo): an order without a postal code crashes shipping.
import { createOrder, resetOrders } from '../../src/orders/OrderService';
import { labels, resetLabels } from '../../src/shipping/ShippingLabelConsumer';
import { validInput } from '../helpers';

test('order without postal code gets a NO POSTCODE label', () => {
  resetOrders(); resetLabels();
  createOrder(validInput({ shippingAddress: { line1: '1 Queen Rd', city: 'Hong Kong', country: 'HK' } as any }));
  expect(labels[0]).toContain('NO POSTCODE');
});
