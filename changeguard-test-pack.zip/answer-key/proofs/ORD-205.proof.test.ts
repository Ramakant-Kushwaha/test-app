// Control: the safe change must work end to end (this test should PASS).
import { createOrder, resetOrders } from '../../src/orders/OrderService';
import { outbox, resetOutbox } from '../../src/notifications/EmailConsumer';
import { labels, resetLabels } from '../../src/shipping/ShippingLabelConsumer';
import { validInput } from '../helpers';

test('gift message flows to the email; other consumers unaffected', () => {
  resetOrders(); resetOutbox(); resetLabels();
  createOrder({ ...validInput(), giftMessage: 'Happy birthday!' } as any);
  createOrder(validInput());
  expect(outbox[0].body).toContain('Gift message: Happy birthday!');
  expect(outbox[1].body).toBe('Thank you for your order ORD-00002.');
  expect(labels).toHaveLength(2);
});
