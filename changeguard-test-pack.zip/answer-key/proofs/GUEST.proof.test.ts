// Reference proof (reduced mode, crash only): a guest order without email crashes the email consumer.
import { createOrder, resetOrders } from '../../src/orders/OrderService';
import '../../src/notifications/EmailConsumer';
import { validInput } from '../helpers';

test('guest order without email does not crash', () => {
  resetOrders();
  expect(() => createOrder(validInput({ customerEmail: undefined } as any))).not.toThrow();
});
