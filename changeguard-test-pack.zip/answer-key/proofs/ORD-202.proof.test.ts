// Reference proof: inventory must reserve exactly the ordered quantity through the real event path.
import { createOrder, resetOrders } from '../../src/orders/OrderService';
import { reservations, resetInventory } from '../../src/inventory/InventoryConsumer';
import { validInput } from '../helpers';

test('inventory reserves the ordered quantity', () => {
  resetOrders(); resetInventory();
  createOrder(validInput());
  expect(reservations.get('SKU-RED-MUG')).toBe(2);
});
