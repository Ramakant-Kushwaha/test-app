# Answer key — keep this OUTSIDE the ChangeGuard workspace

Agents must never see this file. Compare ChangeGuard's result with the expectations below.
Line numbers refer to the files on the scenario branch. All scenarios keep `npm run typecheck` and the existing
`npx jest` suite GREEN — exactly like CI would — so the problem is invisible without ChangeGuard.
Reference proof tests are in `answer-key/proofs/` (verified: they fail on the scenario branch, and pass with the expected fix).

| ID | Kind | Hidden problem | Expected ChangeGuard verdict (before fix) | Label |
|---|---|---|---|---|
| ORD-201 | Cross-service crash | Shipping (not in the diff) crashes on a missing postal code | BLOCKED | Proven |
| ORD-202 | Silent contract drift (no crash) | Inventory reserves NaN because the event field was renamed | BLOCKED (needs the requirement) | Proven (assertion) |
| ORD-203 | Security | SQL built by string concatenation (injection) and SELECT * | Finding reported; no impact on other services | Detected |
| ORD-204 | Performance | Query per customer inside a loop (N+1); string concatenation in a loop | Finding reported | Detected |
| ORD-205 | SAFE control | None — optional gift message handled correctly everywhere | PASSED / no proven issue | — |
| GUEST | No ticket (reduced mode) | Notifications crash on a guest order without email | BLOCKED, reduced mode, fix shows an assumption | Proven (crash) |
| DOCS | Docs only | None | Skipped (no source change) | — |
| SKIP | Opt-out | None (rename) | Skipped ([skip changeguard]) | — |

## ORD-201 — accept addresses without a postal code
- Changed: `src/domain/Order.ts` (postalCode optional), `src/validation/OrderValidator.ts` (check only if present).
- Untouched consumer: `src/shipping/LabelFormatter.ts` keeps its own `ShippingAddress` with `postalCode: string`.
- Path: `createOrder` → `publishOrderCreated` → `bus.emit('order.created')` → `ShippingLabelConsumer.onAddressEvent` → `formatLabel`.
- Proof: TypeError "reading 'trim'" at **src/shipping/LabelFormatter.ts:10** (stack passes ShippingLabelConsumer.ts:17,
  EventPublisher.ts:13, OrderService.ts:39). Same crash via `updateShippingAddress` → `order.address_changed`.
- Expected fix: `address.postalCode?.trim().toUpperCase() ?? 'NO POSTCODE'` + `postalCode?: string` in `ShippingAddress`.
- Wrong fixes: printing an empty string or "undefined"; changing tests; reverting the producer change.

## ORD-202 — use qty for item quantities in order events
- Changed: `src/integrations/EventPublisher.ts` only (`quantity` → `qty` in the payload).
- Untouched consumer: `src/inventory/InventoryConsumer.ts` still reads `item.quantity` → `reservations` becomes NaN. No exception.
- Existing InventoryConsumer tests stay green because they emit hand-written payloads with `quantity`.
- Proof needs the requirement ("reserve exactly the ordered quantity"): through `createOrder`, `reservations.get('SKU-RED-MUG')`
  is NaN, expected 2 (assertion failure — not a crash).
- Expected fix: read `item.qty ?? item.quantity` (type both optional). **Trap:** a fix that reads only `qty` passes the proof
  but breaks the 2 existing InventoryConsumer tests → re-verify must FAIL that fix.
- In reduced mode (no requirement) this cannot be proven — an honest result is "not proven".

## ORD-203 — search orders by customer email
- Changed: `OrderRepository.findByEmail` uses `"SELECT * FROM orders WHERE customer_email = '" + email + "'"`; new
  `searchOrdersByEmail`; a new passing test.
- Expected: security finding (SQL injection via concatenation; also SELECT *), at the findByEmail SQL line. No other service affected.
- Expected fix: parameterised query with an explicit column list (`... WHERE customer_email = ?`, `[email]`).
- Note: the current ChangeGuard rule pack may not include this rule yet — a miss here is a real gap to fix, not a pass.

## ORD-204 — order count per customer in the sales report
- Changed: `SalesReport.customerSummary` calls `repo.findByCustomer` inside the loop (one query per customer) and builds the
  report with `+=` in the loop; a new passing test.
- Expected: performance findings (N+1 query in loop; string concatenation in loop). Detected, not proven (no benchmark).
- Expected fix: one query for all customers (or group `repo.all()` once) and build lines in an array + `join`.

## ORD-205 — optional gift message (SAFE control)
- Changed: Order, OrderService, EventPublisher, EmailConsumer (guarded with `event.giftMessage ? … : ''`), tests.
- Expected: no proven issue; verdict PASSED (or "no issues"). Any BLOCKED verdict here is a FALSE POSITIVE.

## GUEST — allow guest checkout without an email address (no ticket, no body)
- Changed: `customerEmail` optional in Order and CreateOrderInput; email validated only if present.
- Untouched consumer: `src/notifications/EmailConsumer.ts` calls `event.customerEmail.toLowerCase()` →
  TypeError at **src/notifications/EmailConsumer.ts:18**.
- Expected: reduced mode (no requirement); crash proof only; the fix must state an assumption, e.g.
  "assumption: guest orders without an email get no confirmation email".

## DOCS / SKIP
- DOCS changes only README.md → expected "skipped (no source change)", no agent calls.
- SKIP renames a variable with `[skip changeguard]` in the message → expected "skipped (opt-out)".

## Score sheet (fill in per run)
| ID | Verdict | Expected? | Proof VALID first try? | Fix applied first try? | Steps | Time | Notes |
|---|---|---|---|---|---|---|---|
| ORD-201 | | | | | | | |
| ORD-202 | | | | | | | |
| ORD-203 | | | | | | | |
| ORD-204 | | | | | | | |
| ORD-205 | | | | | | | |
| GUEST | | | | | | | |
| DOCS | | | | | | | |
| SKIP | | | | | | | |
