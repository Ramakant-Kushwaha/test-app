# CONTRACTS.md — frozen interfaces

Frozen at hour 9. Changes need the demo commander's approval, a version note at the bottom of this file, and an update to every plan that uses the changed item.

---

## 1. Fixed names and values

| Item | Value |
| --- | --- |
| Sample service | `target-enterprise-app/` (package name `product-pricing-service`) |
| Baseline branch / tag | `main` / `demo-base` |
| PR branch / tag | `feature/promo-null-discount` / `demo-pr` |
| Jira id | `PRICE-142` |
| Requirement text | `Promotional items may have no discount code. Billing must tag a line with no discount code as NONE.` |
| Baseline test total | 18 |
| Expected final total | 19 (18 + 1 generated) |
| Hero target file | `src/billing/InvoiceTaxCalculator.ts` |
| Event name | `billing.line` |
| Agent MCP | `http://<host>:8000/mcp` (streamable HTTP) |
| Reviewer MCP | `http://localhost:8001/mcp` (streamable HTTP) |
| Executor | `http://127.0.0.1:8002/apply` (plain HTTP, not MCP) |
| Backend | `http://localhost:3000` |
| Mission Control | `http://localhost:4200/runs/<run_id>` |
| Orchestrate toolkit name | `changeguard_mcp` |
| Approval lifetime | 10 minutes |
| Patch budget | at most 40 changed lines, only under `src/` |
| Test name pattern | `^[a-z0-9-]{3,48}$`, file `tests/generated/<name>.test.ts` |

## 2. Environment variables

| Variable | Used by | Meaning |
| --- | --- | --- |
| `REPO_ROOT` | tools, executor, backend | Absolute path of `target-enterprise-app` |
| `BACKEND_URL` | tools, executor | `http://localhost:3000` |
| `INTERNAL_API_KEY` | tools, executor, backend | Shared key for `/internal/*` and the executor |
| `AGENT_MCP_CREDENTIAL` | agent MCP | Value checked on each request (only if auth option B is chosen) |
| `WXO_API_ENDPOINT`, `WXO_AGENT_ID`, `WXO_API_KEY` | backend | Orchestrate chat endpoint and credentials |
| `MISSION_CONTROL_URL` | backend | `http://localhost:4200` |

## 3. Stage keys (the only stage vocabulary)

| # | Key | Phase shown | Owner |
| --- | --- | --- | --- |
| 1 | `requirement` | Intake | Scope agent (posted by `get_git_diff`) |
| 2 | `diff` | Impact | Scope agent |
| 3 | `blast_radius` | Impact | Scope agent |
| 4 | `risks` | Impact | Risk agent |
| 5 | `test_gen` | Proof | Verification agent (posted by `write_and_run_tests`) |
| 6 | `red_proof` | Proof | Verification agent |
| 7 | `fix_proposal` | Approval | Remediation agent |
| 8 | `human_gate` | Approval | Reviewer + backend |
| 9 | `reverify_report` | Verify | Executor |

Phases in order: `Intake`, `Impact`, `Proof`, `Approval`, `Verify`.

## 4. Run statuses

`created` → `analyzing` → `awaiting_approval` → `applying` → `done`
Side exits: `analyzing → failed`, `analyzing → done` (no valid proof; verdict NEEDS_REVIEW), `awaiting_approval → rejected`, `applying → failed`.

Verdicts: `BLOCKED`, `NEEDS_REVIEW`, `PASSED`. PASSED only in `done` after `reverify_report`.

## 5. Event envelope

```json
{
  "run_id": "run_20261120_0001",
  "stage": "red_proof",
  "status": "started | done | error",
  "tool": "write_and_run_tests",
  "at": 1763620000000,
  "payload": { }
}
```

Required payload fields per stage:

| Stage | Payload fields |
| --- | --- |
| `requirement` | `acceptance_criteria[]` |
| `diff` | `changed_files[]`, `hunks[]`, `changed_symbols[]`, `changed_fields[]` |
| `blast_radius` | `nodes[] {id, file, kind: changed|dependency|consumer|other}`, `edges[] {from, to, kind: import|event, label}`, `untouched_consumers[] {file, line, snippet, hazard}` |
| `risks` | `findings[] {id, rule_id, hazard, severity, file, line, message}` |
| `test_gen` | `test_name`, `test_code`, `target_file` |
| `red_proof` | `test_name`, `passed`, `failed`, `total`, `messages[]`, `top_src_frame`, `target_statements_hit`, `proof_valid`, `invalid_reason` |
| `fix_proposal` | `proposal_id`, `files[]`, `sha256`, `check_ok`, `changed_lines` |
| `human_gate` | `approval_id` or `rejected`, `approver_name`, `sha256_prefix`, `expires_at` |
| `reverify_report` | `passed`, `failed`, `total`, `per_test[] {file, name, status}`, `findings_after[]`, `applied_files[]` |

Verdict event (backend only): `{ "run_id", "verdict", "reason_codes": [], "baseline_tests", "final_tests", "analysis_ms", "total_ms" }`.

## 6. Tool schemas

### Agent MCP (port 8000) — Orchestrate only

| Tool | Arguments | Returns |
| --- | --- | --- |
| `get_git_diff` | `run_id: str`, `base_ref: str = "demo-base"`, `head_ref: str = "demo-pr"`, `acceptance_criteria: list[str]` | `changed_files`, `hunks`, `changed_symbols`, `changed_fields` |
| `analyze_blast_radius` | `run_id: str`, `changed_files: list[str]`, `changed_fields: list[str]` | `nodes`, `edges`, `untouched_consumers` |
| `run_security_rules` | `run_id: str` | `findings` |
| `write_and_run_tests` | `run_id: str`, `test_name: str`, `test_code: str`, `target_file: str` | the `red_proof` payload |
| `submit_patch_proposal` | `run_id: str`, `unified_diff: str`, `rationale: str` | `proposal_id`, `files`, `sha256`, `check_ok` |

### Reviewer MCP (port 8001) — Bob only

| Tool | Arguments | Returns |
| --- | --- | --- |
| `start_changeguard_run` | `jira_id: str`, `requirement_text: str`, `base_ref: str = "demo-base"`, `head_ref: str = "demo-pr"` | `run_id`, `mission_control_url` |
| `get_run_status` | `run_id: str` | `status`, `phase`, `verdict`, `untouched_consumers` |

### Executor (127.0.0.1:8002) — backend only

`POST /apply`, header `X-Internal-Key`, body `{ "run_id": "...", "approval_id": "..." }`. Steps, in order:
1. `GET /internal/approvals/:id`; refuse unless same run, unused, unexpired, and `sha256(diff) == diff_sha256`.
2. `POST /internal/approvals/:id/consume`; refuse unless exactly one row changed.
3. `git apply --check`, then `git apply`.
4. `npx jest --json --outputFile=<tmp>` (full suite).
5. Rule scan again (same code as `run_security_rules`).
6. Post `reverify_report` event; return the same payload.

## 7. Hazards and severities

| Hazard | Signal | Severity |
| --- | --- | --- |
| `null-deref` | changed field followed by a method call (`.discountCode.toUpperCase(`) | Critical |
| `event-contract-split` | producer and consumer of one event declare the same field with different types | High |
| `unchecked-json-cast` | `JSON.parse(...) as T` with no runtime validation | Medium |

## 8. Proof, risk closure and verdict

```python
proof_valid = (
    jest_ran_test_file
    and not compile_or_import_error      # TS####, SyntaxError, "Cannot find module", "Test suite failed to run"
    and failed >= 1
    and target_statements_hit > 0
    and (failure_is_expect_assertion or top_src_frame.startswith("src/"))
)
```

A Critical or High risk is closed when its linked proof test passes in re-verify, or the post-apply scan no longer reports it.

```python
def compute_verdict(run) -> str:
    proofs = [t.name for t in run.red_proofs if t.proof_valid]
    r = run.reverify
    if r is not None:
        proofs_pass = bool(proofs) and all(r.result(n) == "passed" for n in proofs)
        totals_ok = r.total == run.baseline_total + len(proofs)
        if r.failed == 0 and proofs_pass and totals_ok and open_blocking_risks(run) == 0:
            return "PASSED"
    if any(t.proof_valid and t.failed for t in run.red_proofs) or open_critical(run) > 0:
        return "BLOCKED"
    return "NEEDS_REVIEW"
```

Reason codes: `FULL_SUITE_GREEN`, `PROOF_TESTS_PASS`, `TOTALS_MATCH`, `NO_OPEN_CRITICAL_HIGH`, `VALID_PROOF_FAILING`, `OPEN_CRITICAL`, `NO_VALID_PROOF`.

## 9. Backend API

Public: `POST /api/runs`, `GET /api/runs/:id`, `GET /api/runs/:id/stream`, `POST /api/runs/:id/approve` (`approver_name`, `proposal_id`, `sha256_prefix`), `POST /api/runs/:id/reject` (`approver_name`, `reason`), `GET /api/runs/:id/report?format=json|md`, `POST /api/demo/reset`, `GET /api/replay/:id`.

Internal (127.0.0.1, `X-Internal-Key`): `POST /internal/runs/:id/events`, `POST /internal/runs/:id/proposals`, `GET /internal/approvals/:id`, `POST /internal/approvals/:id/consume`.

Error shape everywhere:

```json
{ "error": { "code": "APPROVAL_HASH_MISMATCH", "message": "Stored proposal does not match approved hash.", "retryable": false } }
```

Error codes and HTTP status: `NOT_FOUND` 404, `APPROVAL_USED` 409, `APPROVAL_EXPIRED` 410, `APPROVAL_WRONG_RUN` 409, `APPROVAL_HASH_MISMATCH` 409, `HASH_PREFIX_MISMATCH` 409, `INVALID_STATE` 409, `PATCH_CHECK_FAILED` 422, `REPLAY_READ_ONLY` 403, `UNAUTHORIZED` 401, `PATH_NOT_ALLOWED` 400, `EVIDENCE_WRITE_FAILED` 502.

## 10. Orchestrate messages

Analysis (backend → supervisor), exactly:

```text
RUN_ID=<run_id>
REQUIREMENT=<requirement text>
BASE_REF=demo-base
HEAD_REF=demo-pr
```

Supervisor final reply: `{"run_id":"","phase":"analysis_done","proposal_id":""}` or `{"run_id":"","phase":"no_proof"}`. Approval never goes to Orchestrate.

---

## Version notes

- v1 (hour 9): initial freeze.
