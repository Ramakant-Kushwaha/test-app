# Plan 04 — watsonx Orchestrate agents (hours 9–15)

**Owner:** Agents + IBM  **Depends on:** plan-01 (auth option), plan-03 (agent MCP running)  **Unblocks:** plan-05 integration, plan-07

## Goal

One supervisor and four specialists, run from the CLI against the stub backend, reach a stored proposal with a valid red proof, and stop. Median analysis time is measured. If it's over 60 seconds or unstable, switch to the single-agent fallback at hour 15.

## Agents

| Agent file | Name | Tools | Output |
| --- | --- | --- | --- |
| `scope_impact_agent.yaml` | `scope_impact_agent` | `changeguard_mcp:get_git_diff`, `changeguard_mcp:analyze_blast_radius` | criteria, changed fields, untouched consumers |
| `risk_security_agent.yaml` | `risk_security_agent` | `changeguard_mcp:run_security_rules` | ordered risks |
| `test_verification_agent.yaml` | `test_verification_agent` | `changeguard_mcp:write_and_run_tests` | one test + proof result |
| `remediation_agent.yaml` | `remediation_agent` | `changeguard_mcp:submit_patch_proposal` | proposal id |
| `changeguard_supervisor.yaml` | `changeguard_supervisor` | collaborators only | `analysis_done` or `no_proof` |
| `changeguard_single_agent.yaml` | `changeguard_single_agent` | all five | fallback only |

Imported toolkit tools are named `toolkit_name:tool_name`. Ready files are in `plans/starter/wxo-agents/`.

## Steps

### 1. Choose the model (5 min)
Run `orchestrate models list`. Put the strongest instruct model id in every `llm:` field (replace `<MODEL>`). If you want speed, the scope agent can use a smaller model.

### 2. Import the toolkit (15 min)

Use the auth option recorded in plan-01.

```bash
cd changeguard-workspace/changeguard-ai
cp ../plans/starter/wxo-agents/*.yaml wxo-agents/

# Option B only: connection whose value the agent server checks
orchestrate connections add -a changeguard_mcp_conn
for env in draft live; do
  orchestrate connections configure -a changeguard_mcp_conn --env $env --type team --kind key_value
  orchestrate connections set-credentials -a changeguard_mcp_conn --env $env -e "MCP_CREDENTIAL=$AGENT_MCP_CREDENTIAL"
done

orchestrate toolkits add --kind mcp \
  --name changeguard_mcp \
  --description "ChangeGuard analysis tools: git diff, blast radius, rules, Jest proof, patch proposal" \
  --url "<agent MCP URL from plan-01>/mcp" \
  --transport streamable_http \
  --tools "get_git_diff,analyze_blast_radius,run_security_rules,write_and_run_tests,submit_patch_proposal" \
  [--app-id changeguard_mcp_conn]

orchestrate tools list -v      # exactly five changeguard_mcp:<tool> entries
```

### 3. Import and deploy (10 min)

```bash
for a in scope_impact_agent risk_security_agent test_verification_agent remediation_agent changeguard_supervisor; do
  orchestrate agents import -f wxo-agents/$a.yaml
done
for a in scope_impact_agent risk_security_agent test_verification_agent remediation_agent changeguard_supervisor; do
  orchestrate agents deploy --name $a
done
orchestrate agents list -v     # copy changeguard_supervisor's id → WXO_AGENT_ID
```

Import specialists before the supervisor.

### 4. Smoke test against the stub backend (30 min, repeat until stable)

```bash
# terminal 1-4: stub backend and the three servers from plan-03
# terminal 5: create a run in the stub, then send the analysis message
RUN_ID=$(curl -s -X POST localhost:3000/api/runs -H 'content-type: application/json' \
  -d '{"jira_id":"PRICE-142","requirement_text":"Promotional items may have no discount code. Billing must tag a line with no discount code as NONE.","base_ref":"demo-base","head_ref":"demo-pr"}' | python -c 'import sys,json;print(json.load(sys.stdin)["run_id"])')

time orchestrate chat ask --agent-name changeguard_supervisor --include-reasoning "RUN_ID=$RUN_ID
REQUIREMENT=Promotional items may have no discount code. Billing must tag a line with no discount code as NONE.
BASE_REF=demo-base
HEAD_REF=demo-pr"
```

Reset between runs: `cd ../target-enterprise-app && git reset -q --hard demo-pr && git clean -fdq tests/generated`.

### 5. Measure (15 min)
Run 3 times. Record each `real` time and outcome in `docs/evidence/04/timing.md`. Compute the median.

### 6. Tune if needed
- Agent picks the wrong risk → make the risk agent's ordering rule stricter (Critical first, then file in `untouched_consumers`).
- Test doesn't compile → add "Use `null as any` for null values; import `computeLine` from '../../src/billing/InvoiceTaxCalculator'" to the test agent.
- Diff fails `git apply --check` → add "Include 3 lines of context; paths a/src/... b/src/...; end with a newline".
- Supervisor improvises → shorten its instructions; keep JSON-only replies.

After any toolkit schema change: `orchestrate toolkits remove --name changeguard_mcp`, add again, re-import and re-deploy every agent.

### Fallback (decide at hour 15)
If median > 60 s or fewer than 3/3 runs reach a valid proof and a proposal:

```bash
orchestrate agents import -f wxo-agents/changeguard_single_agent.yaml
orchestrate agents deploy --name changeguard_single_agent
# set WXO_AGENT_ID to this agent's id; the backend message is unchanged
```

Evidence contracts don't change, so plan-05 and plan-06 need no edits. In the pitch, say "watsonx Orchestrate runs the analysis agent".

## Bob — Agent mode (helper for tuning)

```text
Read plans/CONTRACTS.md and plans/plan-04-orchestrate-agents.md. Using wxo-docs, check that every YAML in
changeguard-ai/wxo-agents matches the current native agent schema (spec_version, kind, name, description,
llm, style, instructions, tools, collaborators). Report any field that doesn't match; change nothing else.
Do not change tool names, agent names or the JSON reply formats.
```

## Acceptance checks

- [ ] `orchestrate tools list -v` shows exactly 5 `changeguard_mcp:` tools.
- [ ] 3 consecutive smoke runs: reasoning trace shows all four specialists in order; stub received `requirement`, `diff`, `blast_radius`, `risks`, `test_gen`, `red_proof` (`proof_valid: true`), `fix_proposal` (`check_ok: true`).
- [ ] Supervisor's final reply is exactly `{"run_id":"...","phase":"analysis_done","proposal_id":"..."}`.
- [ ] `git status --porcelain src` is empty after each run.
- [ ] Median time recorded; fallback decision written down.

## Do not

- Give any agent a tool that applies code. There isn't one on the agent server, and there must never be.
- Send approvals or tokens to Orchestrate.
- Change the analysis message format (CONTRACTS.md §10).
