# ChangeGuard AI — Build Plans

These files turn the ChangeGuard Execution Blueprint into work you can hand to IBM Bob, or follow by hand.

## What's in this folder

| File | What it is | Who uses it |
| --- | --- | --- |
| `AGENTS.md` | Project rules Bob must follow in every task | Copy to the workspace root |
| `CONTRACTS.md` | Frozen interfaces: stage keys, tool schemas, events, verdict, API | Every workstream; never edit without the demo commander |
| `plan-01-environment-auth-gate.md` | Hours 0–2: tools, Orchestrate connection, auth decision | Agents + IBM |
| `plan-02-target-repo.md` | Hours 2–5: sample service and the planted PR | Repo + tools |
| `plan-03-tools-package.md` | Hours 5–9: Python tool package, 3 entry points | Repo + tools |
| `plan-04-orchestrate-agents.md` | Hours 9–15: toolkit import, 5 agents, smoke test | Agents + IBM |
| `plan-05-backend.md` | Hours 12–21: Node backend, SQLite, verdict, approval | Backend + evidence |
| `plan-06-mission-control.md` | Hours 12–27: Angular Mission Control | Frontend + pitch |
| `plan-07-bob-reviewer.md` | Hours 15–27: Bob reviewer mode and opening | Agents + IBM |
| `plan-08-hardening-rehearsal.md` | Hours 27–36: reset, replay, metrics, rehearsal | Everyone; demo commander leads |
| `starter/wxo-agents/*.yaml` | The 5 agent definitions, ready to import | Agents + IBM |
| `starter/tools/ping_server.py` | 20-line MCP server for the hour-2 auth gate | Agents + IBM |

## How to hand a plan to Bob

1. Put this folder at `changeguard-workspace/plans/` and copy `AGENTS.md` to `changeguard-workspace/AGENTS.md`.
2. Open the workspace in Bob.
3. Switch to **Plan** mode and paste the "Bob — Plan mode" prompt from the plan file. Read Bob's file plan; correct it if it breaks `CONTRACTS.md`.
4. Switch to **Agent** mode and paste the "Bob — Agent mode" prompt.
5. Run every command under "Acceptance checks" yourself. A plan is done only when every check passes.
6. Save the command output in `changeguard-ai/docs/evidence/<plan number>/`.

## Order and dependencies

```text
plan-01 ──► plan-02 ──► plan-03 ──► plan-04 ──► plan-07
                           │            │
                           └──► plan-05 ◄┘
                                   │
                                   └──► plan-06 ──► plan-08
```

- plan-05 and plan-06 can start at hour 12 against the stub backend and recorded fixtures from plan-03.
- Interface freeze is at hour 9: after that, `CONTRACTS.md` changes need the demo commander's approval and a note in every affected plan.

## Cut lines (from the blueprint)

| Hour | If not true | Action |
| --- | --- | --- |
| 9 | All five agent tools stable | Keep only the hero hazard rules and executor checks |
| 15 | Median analysis ≤ 60 s, stable over 3 runs | Replace 5 agents with 1 agent holding all 5 tools (plan-04, section "Fallback") |
| 21 | Executor passes all negative tests | Stop UI work; fix governance first |
| 27 | Mission Control works end to end | Drop drill-downs and animation |
| 31 | Five clean live runs | Freeze; use labelled replay and the backup video |
