# Plan 02 — Fixture repo, candidate PR, disposable checkout, manual proof (elapsed hours 0–6)

**Owner:** Person B  **Depends on:** plan-01 step 1 (toolchain)  **Unblocks:** plan-03 · **Gate:** G1

## Goal

A small Node.js 20 + strict TypeScript service where a 3-file candidate PR keeps the existing suite green, but a `null` discount code now travels producer → `billing.line` event → untouched billing consumer and crashes there. You prove this **by hand, through the real event path**, on a disposable checkout, before any AI work. You also record what the same test does on the base revision.

The scenario is intentionally seeded. Everyone says so.

## Design (do not change)

Path: `updatePromoPrice` → `validateDiscount` → `ProductStore.save` → `publishLine` → `JSON.stringify` → `bus.emit('billing.line', raw)` → `BillingConsumer` listener → `JSON.parse(raw) as InvoiceLine` → `computeLine(line)`.

`EventEmitter.emit` is synchronous, so an exception in `computeLine` propagates back up through `publishLine` to `updatePromoPrice`. Billing declares its **own** `InvoiceLine` type and never imports from `src/domain` or `src/controllers`, so strict TypeScript can't see the break.

### Files on `main`

```text
target-enterprise-app/
├── package.json             # scripts: "test": "jest", "typecheck": "tsc --noEmit"
├── package-lock.json        # committed, so npm ci works in demo-work
├── tsconfig.json            # "strict": true, "esModuleInterop": true, "target": "ES2020", "outDir": "dist"
├── jest.config.js           # preset ts-jest; testMatch ['<rootDir>/tests/**/*.test.ts']; collectCoverageFrom ['src/**/*.ts']
├── .gitignore               # node_modules, dist, coverage
├── src/domain/Product.ts
├── src/validators/DiscountValidator.ts
├── src/controllers/ProductController.ts
├── src/store/ProductStore.ts
├── src/events/bus.ts
├── src/integrations/BillingWebhookAdapter.ts
├── src/billing/InvoiceLine.ts
├── src/billing/BillingConsumer.ts
├── src/billing/InvoiceTaxCalculator.ts
└── tests/
    ├── DiscountValidator.test.ts      # 6 tests
    ├── ProductController.test.ts      # 8 tests, jest.mock the adapter
    ├── InvoiceTaxCalculator.test.ts   # 4 tests, non-null codes, price > 0
    └── generated/.gitkeep
```

### Exact code for the billing files

```ts
// src/billing/InvoiceLine.ts
export interface InvoiceLine {
  sku: string;
  price: number;
  cost: number;
  quantity: number;
  discountCode: string; // billing's own copy of the contract
}
```

```ts
// src/billing/InvoiceTaxCalculator.ts
import { InvoiceLine } from './InvoiceLine';

const TAX_RATE = 0.18;
const round2 = (n: number) => Math.round(n * 100) / 100;

export function computeLine(line: InvoiceLine) {
  const net = line.price * line.quantity;
  const promoTag = line.discountCode.toUpperCase(); // keep on line 8
  const netProfit = net - line.cost * line.quantity;
  return {
    sku: line.sku,
    promoTag,
    net: round2(net),
    tax: round2(net * TAX_RATE),
    marginRatio: round2(netProfit / line.price),
  };
}
```

```ts
// src/billing/BillingConsumer.ts
import { bus } from '../events/bus';
import { InvoiceLine } from './InvoiceLine';
import { computeLine } from './InvoiceTaxCalculator';

export const results: ReturnType<typeof computeLine>[] = [];

bus.on('billing.line', (raw: string) => {
  const line = JSON.parse(raw) as InvoiceLine;
  results.push(computeLine(line));
});
```

The `toUpperCase()` call must stay on **line 8**.

### Other files (behaviour)

- `Product.ts`: `Product { sku; name; price; cost; discountCode: string }`, `User { id: string; role: 'admin' | 'editor' }`.
- `DiscountValidator.ts`: `ValidationError` with a `code`; `CODE_PATTERN = /^[A-Z0-9]{4,12}$/`; `validateDiscount(code: string, price: number)` throws `INVALID_CODE` if `code.toUpperCase()` fails the pattern, `INVALID_PRICE` if `price <= 0` or more than 2 decimals.
- `ProductController.ts`: `export interface PromoPriceInput { sku; price; discountCode: string; requestedBy: User }`; **exported function** `updatePromoPrice(input)`: 404 for unknown sku; catches only `ValidationError` → 400; otherwise saves, calls `publishLine(product)`, appends an audit entry, returns `{ status: 200, body: product }`. Other errors propagate.
- `ProductStore.ts`: in-memory `Map` seeded with `P-1`, `P-2`, `P-3`; `get`, `save`, `audit`.
- `bus.ts`: `export const bus = new EventEmitter();`
- `BillingWebhookAdapter.ts`: `publishLine(p)` emits `JSON.stringify({ sku, price, cost, quantity: 1, discountCode })` on `'billing.line'`. It must not import anything from `src/billing`.
- The application entry (`src/index.ts`, optional) imports `BillingConsumer` to register the listener. Tests import it directly.

### The 18 baseline tests (names exactly)

| File | Tests |
| --- | --- |
| `DiscountValidator.test.ts` | accepts a valid code and price · uppercases a lowercase code before checking · rejects a code longer than 12 characters · rejects a code with symbols · rejects a negative price · rejects a price with 3 decimals |
| `ProductController.test.ts` | returns 200 for a valid update · returns 404 for an unknown sku · returns 400 for an invalid code · returns 400 for a negative price · saves the new price to the store · publishes one billing line · writes an audit entry with the requester id · lets an editor change a positive price |
| `InvoiceTaxCalculator.test.ts` | computes net for quantity 1 · computes 18% tax rounded to 2 decimals · uppercases the promo tag · computes a positive margin ratio |

No test passes `null` as a code.

### The candidate PR (branch `feature/promo-null-discount`, one commit)

| File | Change |
| --- | --- |
| `src/domain/Product.ts` | `discountCode: string` → `discountCode: string \| null` |
| `src/validators/DiscountValidator.ts` | `code: string \| null`; pattern check only when `code !== null`; price rule unchanged |
| `src/controllers/ProductController.ts` | `PromoPriceInput.discountCode: string \| null` |

Commit message: `PRICE-142: allow promotional items without a discount code`.

### Disposable checkout (`changeguard-ai/scripts/make-demo-work.sh`)

```bash
#!/usr/bin/env bash
set -euo pipefail
FIXTURE="$(cd "$(dirname "$0")/../../target-enterprise-app" && pwd)"
WORK="$(cd "$(dirname "$0")/../.." && pwd)/demo-work"
SANDBOX="$(cd "$(dirname "$0")/../tools/sandbox" && pwd)"     # from plan-03; skip copy if absent
[ -e "$WORK" ] && { echo "demo-work exists; delete it by hand first"; exit 1; }
git clone -q --no-hardlinks "$FIXTURE" "$WORK"
cd "$WORK"
git fetch -q origin 'refs/tags/*:refs/tags/*'
git checkout -q -B feature/promo-null-discount demo-pr
echo "repo_id=product-pricing-service" > .changeguard-disposable
printf '.changeguard-disposable\n.changeguard/\n.changeguard.lock\njest.sandbox.config.js\n' >> .git/info/exclude
[ -d "$SANDBOX" ] && { mkdir -p .changeguard && cp "$SANDBOX/block-io.js" .changeguard/ && cp "$SANDBOX/jest.sandbox.config.js" .; }
npm ci --silent
git rev-parse demo-pr
```

`demo-work/` is the only directory any tool, the executor or the reset script may change.

### The manual event-path proof (not committed to the fixture)

Save as `changeguard-ai/docs/evidence/02/promo-null-event.test.ts`; copy into `demo-work/tests/generated/` to run.

```ts
import { updatePromoPrice } from '../../src/controllers/ProductController';
import { results } from '../../src/billing/BillingConsumer';

it('tags a promotional line with no discount code as NONE after billing.line', () => {
  results.length = 0;
  const res = updatePromoPrice({
    sku: 'P-1', price: 10, discountCode: null as any,
    requestedBy: { id: 'u-1', role: 'editor' },
  });
  expect(res.status).toBe(200);
  expect(results).toHaveLength(1);
  expect(results[0].promoTag).toBe('NONE');
});
```

## Bob — Plan mode

```text
Read AGENTS.md, plans/CONTRACTS.md and plans/plan-02-target-repo.md.
Plan the fixture target-enterprise-app exactly as specified: every file, the exact code for InvoiceLine.ts,
InvoiceTaxCalculator.ts and BillingConsumer.ts, the 18 named tests, the commit on main, the candidate commit on
feature/promo-null-discount, tags demo-base and demo-pr, and changeguard-ai/scripts/make-demo-work.sh.
List every command and how each acceptance check will be met. Do not write files yet.
```

## Bob — Agent mode

```text
Implement the approved plan-02 plan.
1. Create target-enterprise-app on main (dev deps: typescript, jest, ts-jest, @types/jest, @types/node, ts-node).
   npm run typecheck and npx jest must pass. Commit "seed: product-pricing-service". Tag demo-base.
2. git checkout -b feature/promo-null-discount; change ONLY the 3 files in "The candidate PR".
   Typecheck and jest must pass. Commit with the given message. Tag demo-pr.
3. Create changeguard-ai/scripts/make-demo-work.sh exactly as written and run it.
4. Run the acceptance checks in plan-02 inside demo-work and show the full output. Do not commit the manual test.
```

## Acceptance checks (gate G1)

Run inside `demo-work/` and save all output to `changeguard-ai/docs/evidence/02/`.

```bash
cd demo-work
cat .changeguard-disposable                         # repo_id=product-pricing-service
git rev-parse HEAD demo-pr demo-base                # HEAD == demo-pr; record both commits
npx tsc --noEmit; echo "exit=$?"                    # exit=0
npx jest --json --outputFile=/tmp/base.json --testPathIgnorePatterns tests/generated; echo "exit=$?"
python3 -c "import json;d=json.load(open('/tmp/base.json'));print(d['numPassedTests'],d['numFailedTests'],d['numTotalTests'])"
git diff --stat demo-base...demo-pr                 # 3 files, none under src/billing
sed -n 8p src/billing/InvoiceTaxCalculator.ts       # the toUpperCase line

# Event-path proof on the candidate
cp ../changeguard-ai/docs/evidence/02/promo-null-event.test.ts tests/generated/
npx jest tests/generated/promo-null-event.test.ts; echo "exit=$?"
# Expect: exit 1; TypeError ... reading 'toUpperCase'; stack shows InvoiceTaxCalculator.ts:8,
# BillingConsumer.ts, BillingWebhookAdapter.ts, ProductController.ts

# Same test on the base revision (comparison)
git stash -u -q && git checkout -q demo-base && git stash pop -q
npx jest tests/generated/promo-null-event.test.ts; echo "exit=$?"
# Expect: fails in DiscountValidator.ts (null rejected or crashes at intake) — it never reaches billing
git checkout -q -f feature/promo-null-discount && git clean -fdq tests/generated && git status --porcelain
```

- [ ] Baseline counts and exit code recorded with the candidate commit.
- [ ] Candidate: the event-path test fails with a frame at `src/billing/InvoiceTaxCalculator.ts:8` and the stack passes through consumer, adapter and controller.
- [ ] Base: the same test fails before billing (record exactly where). This is the comparison; say "on the base revision, null never reached billing", not more.
- [ ] Applying the reference fix from CONTRACTS.md §7 by hand makes the test pass; then `git checkout -- src` restores the candidate. Record both runs.
- [ ] `git status --porcelain` is clean at the end.

## Do not

- Add a null test, a role check, or extra features to the fixture.
- Let anything under `src/billing` import from `src/domain` or `src/controllers`, or let the adapter import billing.
- Run anything that changes files outside `demo-work/` after the fixture is tagged.
