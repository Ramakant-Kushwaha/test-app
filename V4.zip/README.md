# ChangeGuard AI — Build Plans

These files turn the ChangeGuard Execution Blueprint into work you can hand to IBM Bob, or follow by hand. Four people, one seeded scenario, one evidence chain.

## First hour, before anything else

1. Confirm on the submission platform: the exact cutoff **with time zone** (stated as 23 November), required submission fields, video length, and whether IBM Bob and watsonx Orchestrate use must be live, build-time or both.
2. Confirm every member can sign in to IBM Bob and the watsonx Orchestrate instance you will demo on. If not, contact the organizers now.
3. Plan backwards: finish rehearsal at least 12 hours before the cutoff and upload at least 3 hours before it.

## What's in this folder

| File | What it is | Owner |
| --- | --- | --- |
| `AGENTS.md` | Rules Bob follows in every task (copy to the workspace root) | All |
| `CONTRACTS.md` | Frozen interfaces: values, stages, payloads, tools, proof, verdict, approval, replay, API | All; changes need the demo commander |
| `plan-01-environment-auth-gate.md` | Event rules, IBM access, toolchain, MCP auth decision | Person A |
| `plan-02-target-repo.md` | Fixture repo, candidate PR, disposable checkout, manual event-path proof | Person B |
| `plan-03-tools-package.md` | Analysis tools (B) and executor + evidence client (C) | Persons B and C |
| `plan-04-orchestrate-agents.md` | Toolkit import, single analyst agent, optional specialists | Person A |
| `plan-05-backend.md` | Backend, evidence store, verdict, approval, replay | Person C |
| `plan-06-mission-control.md` | One-screen Mission Control and report | Person D |
| `plan-07-bob-reviewer.md` | Bob reviewer mode and the opening | Person A |
| `plan-08-hardening-rehearsal.md` | Reset, replay, rehearsal, metrics, video | Person D leads; all |
| `SUBMISSION.md` | Problem, solution, technology, innovation, limitations, Q&A | Person A |
| `starter/wxo-agents/*.yaml` | Primary single agent + optional specialist agents | Person A |
| `starter/tools/ping_server.py` | Auth-gate ping server | Person A |

## Team

| Person | Owns | Deliverable |
| --- | --- | --- |
| A — IBM and pitch (demo commander) | Event rules, IBM access, Orchestrate agent, Bob, submission | Verified access or a written blocker; visible Bob use; submission uploaded |
| B — Fixture and analysis | Fixture repo, disposable checkout, diff, blast radius, rules, test runner and proof classifier | True baseline; event-path red; fixed control green |
| C — Execution and evidence | Executor, backend, verdict, approval, replay enforcement | Exact-diff, commit-bound, single-use approval; full rerun; server-side replay |
| D — Screen and rehearsal | Mission Control, report, scripts, rehearsal log, video | Legible live evidence; exact diff review; labelled replay; video |

## Elapsed-hour plan and gates

Count hours from when work starts, not calendar dates.

| Hours | A | B | C | D | Gate at the end |
| --- | --- | --- | --- | --- | --- |
| 0–2 | plan-01 | plan-02 start | backend skeleton + schema | UI shell | **G0**: rules and cutoff confirmed; Bob access; ping called from Orchestrate with chosen auth |
| 2–6 | Bob build MCP; agent YAML draft | plan-02 finish | executor core + evidence client | UI against a hand-written fixture | **G1**: candidate builds; real baseline saved; manual event-path test fails in billing; base comparison recorded |
| 6–12 | plan-04 (single agent) | plan-03 analysis tools | plan-03 executor; plan-05 core | plan-06 against recorded tool events | **G2**: Orchestrate drives the tools and produces a valid red proof; an invalid test is rejected as INCONCLUSIVE |
| 12–18 | plan-07 | proof classifier hardening | plan-05 approval, verdict, replay | plan-06 live | **G3**: exact-diff approval; changed-HEAD, tampered-bytes, expired, reused and spoofed-replay requests rejected; approved patch gives a green full rerun in `demo-work/` |
| 18–24 | specialists only if G3 is green and they measurably help | fixes | report, metrics | end-to-end screen | **G4**: browser flow started from Bob ends PASSED — within tested scope |
| 24–30 | SUBMISSION.md | rehearsal | rehearsal | plan-08 | **G5**: 5 clean consecutive runs logged; replay and video checked |
| 30–36 | upload | buffer | buffer | buffer | Submitted, with time to spare |

If a gate fails: cut scope, never invent results.

## How to hand a plan to Bob

1. Put this folder at `changeguard-workspace/plans/` and copy `AGENTS.md` to the workspace root.
2. In Bob **Plan** mode, paste the plan's "Bob — Plan mode" prompt. Check Bob's file plan against `CONTRACTS.md`.
3. In **Agent** mode, paste the "Bob — Agent mode" prompt.
4. Run every acceptance check yourself; save output in `changeguard-ai/docs/evidence/<plan number>/`.
5. Keep Bob session exports or screenshots for the submission.

## Dependencies

```text
plan-01 ──► plan-02 ──► plan-03 ──► plan-04 ──► plan-07
                           │            │
                           └──► plan-05 ◄┘
                                   │
                                   └──► plan-06 ──► plan-08 ──► SUBMISSION
```
