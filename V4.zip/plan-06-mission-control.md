# Plan 06 — Mission Control (elapsed hours 6–24)

**Owner:** Person D  **Depends on:** plan-03 fixture `hero-run.jsonl`; plan-05 for live data  **Unblocks:** plan-08 · **Gate:** G4

## Goal

One Angular screen carries the whole demo. A new observer who looks at it for five seconds can say what changed, which untouched code is at risk, whether the failure is proven, and what the verdict is. Every value comes from the API or SSE. Uncertainty is shown, not hidden.

## Stack

Angular (standalone components, Signals), Tailwind CSS, `cytoscape` + `cytoscape-dagre`, `diff2html`, `highlight.js`. Dev server `http://localhost:4200`, proxy `/api` → `http://127.0.0.1:3000`.

## Layout

```text
changeguard-ai/frontend/src/app/
├── app.routes.ts                 # '' → home (Run form), 'runs/:id' → Mission Control, 'runs/:id/report', 'replay/:id'
├── core/
│   ├── api.service.ts            # REST calls
│   ├── run-store.service.ts      # EventSource; signals: run, baseline, phases, graph, proof, proposal, final, verdict, events
│   └── models.ts                 # types from CONTRACTS.md §5
├── mission-control/
│   ├── mission-control.component.ts
│   ├── header-bar.component.ts
│   ├── phase-strip.component.ts
│   ├── blast-radius.component.ts
│   ├── live-evidence.component.ts
│   ├── proposal-bar.component.ts
│   ├── proposal-drawer.component.ts
│   ├── evidence-drawer.component.ts
│   └── replay-banner.component.ts
└── report/report.component.ts
```

## Screen specification

| Region | Contents | Source |
| --- | --- | --- |
| Header bar | "ChangeGuard AI" · `jira_id` · **Baseline: {passed} passed, {failed} failed, exit {exit_code} @ {commit[0:8]}** · verdict badge · run timer · "Started from Bob" when `source = bob` · small "Seeded scenario" tag | `GET /api/runs/:id`, `baseline` and verdict events |
| Phase strip | Intake → Impact → Proof → Approval → Verify; each with icon + word (Waiting, Running, Done, Error) + seconds | stage events mapped by CONTRACTS.md §3 |
| Blast radius (left, 55%) | Cytoscape, dagre left to right. Changed = blue; dependency = grey; consumer = red with ⚠ and "untouched". Import edges solid; event edge dashed with its label. The recorded path is drawn thicker. Under the graph: "Detected by: rule pack (hypothesis until proven)". Clicking a node shows its flagged line and hazard | `blast_radius`, `risks` |
| Live evidence (right, 45%) | Test name and command; **Jest {passed}/{total}, exit {exit_code}**; first error line; **Path reached:** each path file with ✓ and statement count; **VALID PROOF** or **INCONCLUSIVE: {invalid_reason}**; base comparison line if present ("On {base[0:8]}: null never reached billing"). After the fix: **Re-verify: {passed} passed, {failed} failed, exit {exit_code}**, the proof test's status, "Fresh scan: ok" | `red_proof`, `reverify_report` |
| Proposal bar (bottom) | "Exact proposal: {files.length} files · {sha256[0:12]}…" + **Review exact fix** | `fix_proposal` |
| Proposal drawer | diff2html side by side; file list; **full 64-character SHA-256** in monospace; candidate commit; approver name (labelled "typed name, not authenticated"); **Approve this exact diff** and **Reject** (with reason) | `GET /api/runs/:id` |
| Replay banner | "Replay of verified run {id}, recorded {time}", persistent, high contrast | `event: replay` |

### Rules
- Never show a total as a passed count. Always show passed, failed and exit code from the payload.
- **Approve** is enabled only when `status = awaiting_approval`, a proposal exists, a name is typed, and the page is not in replay. It sends `{ approver_name, proposal_id, sha256 }` with the full hash shown. The server decides; the button state is a convenience.
- After approve: "Approved by {name} at {time} · applying…", then the drawer closes on `reverify_report`.
- Verdict badge: BLOCKED (red, ⛔ + word), NEEDS REVIEW (amber, ! + word), **PASSED — within tested scope** (green, ✓ + words). Never colour alone. Show the reason codes on hover or in the evidence drawer.
- After any reconnect, approval, or end of replay, reload `GET /api/runs/:id`; server state wins.
- Evidence drawer: every event, raw output collapsed, newest last.
- Footer: disposable checkout head (short commit) from the last reset, **Reset demo** (confirm dialog), "Replay last verified run".
- Report page: verdict history with reason codes, baseline and final counts with exit codes, path, proof, findings with closure evidence, approval, metrics, limitations and disclosure; Markdown/JSON export.
- No hard-coded numbers, file names or hashes in templates.

### Home page (`/`)
A small form pre-filled with PRICE-142, the requirement text and refs from CONTRACTS.md §1, and **Run ChangeGuard** (`POST /api/runs`, then navigate). For runs not started from Bob.

## Build order

1. Fixture mode (`?fixture=1`): `RunStore` plays `assets/fixtures/hero-run.jsonl` with gaps capped at 1 s. Build every component against this real recorded data.
2. Live mode: SSE from plan-05.
3. Replay mode: `/replay/:id` uses `GET /api/replay/:id` and shows the banner.

## Bob — Plan mode

```text
Read AGENTS.md, plans/CONTRACTS.md and plans/plan-06-mission-control.md.
Plan the Angular app in changeguard-ai/frontend exactly as specified: components, RunStore signals and how each
event updates them, the phase mapping, the fixture player, replay mode, and the display rules (real counts and
exit codes, full hash, INCONCLUSIVE, PASSED — within tested scope). Show a text wireframe at 1440x900.
Do not write files yet.
```

## Bob — Agent mode

```text
Implement the approved plan-06 plan with Angular standalone components and Signals, Tailwind, cytoscape +
cytoscape-dagre, diff2html and highlight.js. Start in fixture mode using src/assets/fixtures/hero-run.jsonl.
Types from plans/CONTRACTS.md §5. No hard-coded demo values in templates. Add component tests for the phase
mapping, baseline rendering (passed/failed/exit, never total/total), the approve-button rule, the verdict label,
and the replay banner. Run ng test and ng build.
```

## Acceptance checks (gate G4, with plans 05 and 07)

- [ ] `?fixture=1` plays the hero run: baseline shows passed, failed and exit code; the path is drawn through a dashed `billing.line` edge to a red billing node; every path file shows ✓; VALID PROOF; proposal bar with 2 files.
- [ ] Feed a fixture where the test fails at import: the panel shows INCONCLUSIVE `setup_failed` and the verdict is NEEDS REVIEW.
- [ ] Live: a run started from Bob reaches **PASSED — within tested scope** with no terminal use; the drawer showed the full hash.
- [ ] Approve stays disabled before `awaiting_approval`, without a name, and in replay; a forced request is refused by the server anyway.
- [ ] Restart the backend mid-run: the page recovers state on reconnect.
- [ ] Template search finds no literal `18`, `19`, `InvoiceTaxCalculator` or hash strings.
- [ ] Five-second test: someone new sees the BLOCKED screen for five seconds and can say what changed, what's at risk, whether it's proven, and the verdict.

## Do not

- Build against invented data. Use the recorded fixture or the live API.
- Add tabs to the live story; drill-downs are drawers.
- Hide INCONCLUSIVE results, failures or the seeded-scenario label.
