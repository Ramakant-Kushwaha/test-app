# Plan 03 — Tool package, executor and stub backend (elapsed hours 6–12)

**Owners:** Person B (analysis tools, proof classifier) and Person C (executor, evidence client, stub backend)
**Depends on:** plan-01 (auth option), plan-02 (fixture, `demo-work/`)  **Unblocks:** plan-04, plan-05, plan-06 · **Gate:** G2 (with plan-04)

## Goal

One Python package, `changeguard_tools`, holds every deterministic action. Three small servers expose it, so each caller sees only its own surface. Everything runs against the disposable checkout `demo-work/` (`WORK_ROOT`), never the fixture.

| Entry point | Bind | Caller | Exposes |
| --- | --- | --- | --- |
| `serve_agents.py` | `:8000` (see plan-01 auth option) | watsonx Orchestrate | 5 analysis tools (MCP) |
| `serve_reviewer.py` | `127.0.0.1:8001` | IBM Bob | 2 reviewer tools (MCP) |
| `serve_executor.py` | `127.0.0.1:8002` | Backend only | `POST /apply` (plain HTTP) |

A **stub backend** lets you test everything before plan-05 exists and records real events as fixtures for plan-06. All names, arguments and payloads come from `CONTRACTS.md`.

## Layout

```text
changeguard-ai/tools/
├── requirements.txt              # fastmcp>=2,<3, uvicorn, httpx, starlette, pyyaml, pytest — pin exact versions
├── .env.example                  # WORK_ROOT, BACKEND_URL, INTERNAL_API_KEY, AUTH_MODE, AUTH_HEADER, AGENT_MCP_CREDENTIAL
├── rules.yaml
├── sandbox/
│   ├── block-io.js               # copied into demo-work/.changeguard/ by make-demo-work.sh
│   └── jest.sandbox.config.js    # copied into demo-work/
├── changeguard_tools/
│   ├── config.py                 # env; WORK_ROOT checks (marker, repo_id, origin == fixture path); path guards
│   ├── proc.py                   # run(cmd, env, timeout) → {command, exit_code, duration_ms, raw_output}; shell=False; 64 KB cap
│   ├── lock.py                   # exclusive lock on WORK_ROOT/.changeguard.lock via fcntl.flock (same lock type as the reset script's flock)
│   ├── evidence.py               # post_event(), store_proposal(), get_approval(), consume_approval()
│   ├── state.py                  # per-run memory: diff, blast radius, findings (re-computable)
│   ├── diff.py                   # get_git_diff (B)
│   ├── graph.py                  # import graph, event edges, reachability, paths (B)
│   ├── hazards.py                # hazard detection with guard rules (B)
│   ├── rules.py                  # rule pack runner; scan_ok; findings (B)
│   ├── jest_runner.py            # run one file / full suite; parse JSON; coverage; classify (B)
│   ├── base_compare.py           # optional base-revision comparison (B)
│   ├── proposals.py              # diff validation, git apply --check, sha256 (C)
│   └── executor_core.py          # the 8 executor steps (C)
├── serve_agents.py
├── serve_reviewer.py
├── serve_executor.py
├── stub_backend.py               # in-memory backend on 127.0.0.1:3000 (C)
├── scripts/client_check.py       # end-to-end check through MCP and the executor
├── fixtures/                     # real events recorded by stub_backend (for plan-06)
└── tests/                        # pytest, no network
```

## Start-up checks (`config.py`)

Every server refuses to start unless:
- `WORK_ROOT` is absolute, exists, contains `.changeguard-disposable` with `repo_id=product-pricing-service`;
- `git -C WORK_ROOT remote get-url origin` resolves to the fixture path;
- `WORK_ROOT` is not the fixture path and not the workspace root.

Path guard: every file argument is resolved with `realpath` and must stay inside `WORK_ROOT`; symlinks that escape are refused with `PATH_NOT_ALLOWED`.

## Generated-test limits (`sandbox/`)

```js
// sandbox/block-io.js — loaded with setupFilesAfterEnv; blocks I/O that generated tests must not use
const blocked = ['net', 'http', 'https', 'dgram', 'child_process', 'worker_threads'];
for (const name of blocked) {
  for (const id of [name, `node:${name}`]) {
    jest.mock(id, () => new Proxy({}, {
      get(_target, prop) {
        if (prop === '__esModule' || prop === 'then' || typeof prop === 'symbol') return undefined;
        throw new Error(`ChangeGuard limits: ${id}.${String(prop)} is blocked in generated tests`);
      },
    }));
  }
}
```

```js
// sandbox/jest.sandbox.config.js
const base = require('./jest.config.js');
module.exports = {
  ...base,
  maxWorkers: 1,
  testTimeout: 30000,
  setupFilesAfterEnv: [...(base.setupFilesAfterEnv || []), '<rootDir>/.changeguard/block-io.js'],
};
```

Every Jest call made by the tools or the executor uses `--config jest.sandbox.config.js`, a 60-second process limit, and a scrubbed environment: `PATH`, `HOME=<tmp dir>`, `NODE_ENV=test`, `CI=1`, nothing else. This is an application-level guard, not an OS sandbox. If Docker is available and time allows, run Jest in `docker run --network none -v $WORK_ROOT:/work -w /work node:20 ...` and record which variant was used.

## Algorithms (implement exactly)

### `get_git_diff` (B)
1. Post `requirement` with `acceptance_criteria`.
2. Refs must match `^[\w./-]+$`. Record `base_commit = git rev-parse <base>`, `head_commit = git rev-parse <head>`.
3. `git diff --unified=0 <base>...<head>` → `changed_files` (from `+++ b/`), `hunks` (file, old/new start, lines).
4. `changed_symbols`: identifiers on changed lines declared as `function`, `class`, `interface` or `const`.
5. `changed_fields`: property names on changed lines (`(\w+)\??\s*:` or `\.(\w+)`) that are also declared as an interface field in `src/`. Demo result: `["discountCode"]`.
6. Post `diff` (with command, exit code, raw output); store in run state; return.

### `analyze_blast_radius` (B)
1. Parse every `src/**/*.ts`: relative imports `from '(\.{1,2}/[^']+)'`; `bus.emit('X'` and `bus.on('X'` event names.
2. Edges: `import` importer → imported; `event` emitter file → listener file, `label = X`.
3. Start set = changed files + files that import a changed file.
4. Breadth-first search from the start set along import edges (importer → imported) and event edges; keep parent pointers.
5. In each reached file outside the changed set, scan for each changed field; tag hazards (below).
6. For every consumer with a Medium-or-higher hazard, `paths[]` gets `{target_file, files[]}`: the parent chain from a changed file with executable code to the consumer. Demo: `ProductController.ts → BillingWebhookAdapter.ts → BillingConsumer.ts → InvoiceTaxCalculator.ts`.
7. Node kinds: `changed`, `consumer`, `dependency`, `other`. `detection: "rules"`.
8. Post `blast_radius`; store; return.

### Hazards (B)
- `null-deref` (Critical): `\.(FIELD)\.(\w+)\(` on a line **with no guard** on that line: `?.`, `FIELD ?`, `FIELD &&`, `!= null`, `!== null`. Location `file:line`.
- `event-contract-split` (High): for each event edge, compare the declared type text of FIELD in interfaces reachable by import from the emitter vs from the listener. Different → hazard at the listener-side declaration.
- `unchecked-json-cast` (Medium): `JSON\.parse\([^)]*\)\s+as\s+\w+` with no `zod`, `.parse(` or `validate` within 3 lines.

### `run_security_rules` (B)
Run `rules.yaml` (regex rules: `id`, `pattern`, `severity`, `message`, `paths`) and convert the stored hazards into findings `{id, rule_id, hazard, severity, file, line, message, status: "hypothesis"}`. `scan_ok` = every `src/**/*.ts` file was read and every rule compiled; `scan_commit` = HEAD. Post `risks`; store; return.

### `write_and_run_tests` (B)
1. Validate `test_name` (`^[a-z0-9-]{3,48}$`) and `target_file` (exists under `src/`).
2. Look up the stored path whose `target_file` matches; `path_files` = its files. No stored path → `proof_status: INCONCLUSIVE`, `invalid_reason: no_recorded_path`.
3. Take the lock. Post `test_gen` (`test_name`, `test_code`, `target_file`, `path_files`).
4. Write `tests/generated/<test_name>.test.ts`.
5. Run with the limits above: `npx jest --config jest.sandbox.config.js --json --outputFile=<tmp>/r.json --coverage --coverageReporters=json --coverageDirectory=<tmp>/cov --collectCoverageFrom=<each path file> tests/generated/<test_name>.test.ts`.
6. Classify from the JSON:
   - `collected_and_setup_ok`: false if the suite status message contains `Test suite failed to run`, `Cannot find module`, `SyntaxError`, a `TS\d{4}` code, or the run hit the time limit.
   - `failure_kind`: `setup`, `timeout`, `assertion` (any `failureDetails[].matcherResult`), `thrown` (an error with no matcher result), or `none`.
   - `top_src_frame`: first stack frame whose path, relative to `WORK_ROOT`, starts with `src/`, as `src/...:line`.
   - `path_files_hit`: statements covered per path file from `coverage-final.json`. Files with zero executable statements (type-only files) are skipped. `path_reached` = every remaining path file has at least 1 covered statement.
   - `proof_valid` per CONTRACTS.md §8, using the hazard locations of Critical findings from run state. `invalid_reason` = the first failing condition (`setup_failed`, `timeout`, `did_not_fail`, `path_not_reached`, `failure_elsewhere`, `no_recorded_path`).
7. Optional (ship if green by G3), `base_compare.py`: `git worktree add <tmp>/base <base_commit>`, symlink `node_modules`, copy the test, run with the same limits, record `{commit, failed, top_src_frame}` as `base_comparison`, remove the worktree.
8. Post `red_proof` with raw output; release the lock; return.

### `submit_patch_proposal` (C)
1. Normalise line endings to `\n`; keep the bytes exactly after that.
2. Files from `+++ b/`; refuse any not under `src/` (`PATH_NOT_ALLOWED`). `changed_lines` = `+`/`-` lines excluding headers; refuse above 40.
3. Write to a temp file; `git apply --check <tmp>` in `WORK_ROOT`.
4. `sha256` = hex digest of the stored bytes; `head_commit` = HEAD.
5. If `check_ok`: `POST /internal/runs/:id/proposals` with `{diff, sha256, files, rationale, check_ok, changed_lines, head_commit}` → `proposal_id`; post `fix_proposal`. Otherwise post `fix_proposal` with `status: error` and the git message.
6. Return `proposal_id`, `files`, `sha256`, `check_ok`, `changed_lines`.

### Executor `POST /apply` (C)
Implement CONTRACTS.md §6 steps 1–8 exactly, in order, stopping at the first failure:
- Lock busy → 423 `LOCKED`. Marker wrong → 400 `NOT_DISPOSABLE`. HEAD differs → 409 `HEAD_CHANGED`. `src` dirty → 409 `WORKTREE_DIRTY`.
- Approval checks → the error codes in CONTRACTS.md §12. Consume before touching files.
- `git apply` failure → 422 `PATCH_CHECK_FAILED`, files unchanged.
- Full suite: all test files, sandbox config, scrubbed env, 120-second process limit. `per_test` from `testResults[].assertionResults[]` as `{file: <path relative to WORK_ROOT>, name: fullName, status}`.
- Fresh scan: same code as `run_security_rules` over the patched tree; `scan_tree` from a temporary index (`GIT_INDEX_FILE=<tmp> git read-tree HEAD && git add -A -- src tests && git write-tree`).
- Post `reverify_report`. If that post fails after `git apply`, return 502 `EVIDENCE_WRITE_FAILED`; the backend marks the run `failed`; the checkout must be reset. No rollback is attempted or promised.

### Evidence and errors
- `post_event` raises `EVIDENCE_WRITE_FAILED` if the backend doesn't answer 2xx within 10 s. Tools never return a result without its stored event.
- Every command result carries `command`, `exit_code`, `duration_ms`, `raw_output`.
- Errors use CONTRACTS.md §12.

### Auth
Agent server: `AUTH_MODE=none` (only for plan-01 options A and C) or `AUTH_MODE=header` with `AUTH_HEADER` + `AGENT_MCP_CREDENTIAL` (option B); a middleware returns 401 on mismatch. Reviewer and executor bind `127.0.0.1`; the executor also requires `X-Internal-Key` (constant-time compare).

### Stub backend (`stub_backend.py`, `127.0.0.1:3000`) (C)
In memory: `POST /api/runs` (also runs the baseline Jest call and posts a `baseline` event), `GET /api/runs/:id`, the four `/internal/*` routes, and a test-only `POST /stub/approve/:run_id` that creates an approval for the latest proposal with its full `sha256` and `head_commit` (expires in 10 min). Appends every event to `fixtures/<run_id>/events.jsonl`.

## Bob — Plan mode

```text
Read AGENTS.md, plans/CONTRACTS.md and plans/plan-03-tools-package.md.
Plan changeguard-ai/tools exactly as in the Layout, Start-up checks, Generated-test limits and Algorithms sections.
For each module: public functions with signatures, which CONTRACTS.md rule it implements, and its unit tests.
List test cases for: missing marker, symlink escape, invalid test names, broken import (INCONCLUSIVE setup_failed),
test that never reaches billing (path_not_reached), assertion on an unrelated value with path reached but failure
elsewhere, test using child_process (blocked), hero event-path test (VALID), guarded null-deref not flagged,
patch outside src/, patch over 40 lines, HEAD changed, dirty src, approval reuse, expiry, wrong run, hash mismatch,
missing internal key, lock busy, evidence write failure before and after apply, failed scan (scan_ok false).
Do not write files yet.
```

## Bob — Agent mode

```text
Implement the approved plan-03 plan in changeguard-ai/tools.
FastMCP 2.x: `mcp = FastMCP("changeguard-agents")`, `@mcp.tool` functions, `app = mcp.http_app()`, served with uvicorn.
Tool names, argument names and return fields must match plans/CONTRACTS.md exactly.
Write the unit tests first, then the code, then scripts/client_check.py, which uses fastmcp.Client against :8000 and
:8001 (sending the auth header when AUTH_MODE=header) and runs: start a stub run → get_git_diff →
analyze_blast_radius → run_security_rules → write_and_run_tests with the event-path test from plan-02 →
submit_patch_proposal with the reference fix from CONTRACTS.md §7 → POST /stub/approve → POST :8002/apply.
Run pytest and the acceptance checks in plan-03 and show the output.
```

## Acceptance checks

```bash
cd changeguard-ai/tools && source ../../.venv/bin/activate
pytest -q                                              # all pass, no network
python stub_backend.py &
python serve_agents.py & python serve_reviewer.py & python serve_executor.py &
python scripts/client_check.py
```

`client_check.py` must assert:

- [ ] A `baseline` event with real counts, exit code and the candidate commit.
- [ ] `changed_fields == ["discountCode"]`; 3 changed files, none under `src/billing`; `head_commit == demo-pr`.
- [ ] A path `ProductController.ts → BillingWebhookAdapter.ts → BillingConsumer.ts → InvoiceTaxCalculator.ts` with an `event` edge labelled `billing.line`.
- [ ] Findings: Critical `null-deref` at `InvoiceTaxCalculator.ts:8`, High `event-contract-split` at `InvoiceLine.ts`, all `status: hypothesis`; `scan_ok: true`.
- [ ] Broken import → INCONCLUSIVE `setup_failed`. Direct `computeLine` test with no controller call → INCONCLUSIVE `path_not_reached`. Test calling `child_process` → fails with the ChangeGuard limits message and is INCONCLUSIVE.
- [ ] Event-path test → `failure_kind: thrown`, `top_src_frame: src/billing/InvoiceTaxCalculator.ts:8`, every executable path file hit, VALID.
- [ ] Diff touching `tests/` → `PATH_NOT_ALLOWED`; the reference fix → `check_ok: true`, full 64-char `sha256`.
- [ ] Executor: no key → 401; wrong run → 409; HEAD moved (make a commit) → 409 `HEAD_CHANGED`; tampered stored diff → 409 `APPROVAL_HASH_MISMATCH`; lock held → 423.
- [ ] Good apply → `exit_code: 0`, `failed: 0`, the event-path test passed, `scan_ok: true`, no `null-deref` or `event-contract-split` in `findings_after`. Second apply → 409 `APPROVAL_USED`.
- [ ] Reviewer `start_changeguard_run` returns a `run_id` and URL.
- [ ] With `AUTH_MODE=header`, a request without the header → 401.
- [ ] The fixture repo is byte-for-byte unchanged (`git -C target-enterprise-app status --porcelain` empty).

Copy `fixtures/<run_id>/events.jsonl` from the good run to `changeguard-ai/frontend/src/assets/fixtures/hero-run.jsonl` for plan-06.

## Do not

- Let any agent tool write under `src/` or outside `WORK_ROOT`.
- Return a tool result whose event wasn't stored.
- Add tools beyond the 5 + 2 + executor.
- Run any git command that changes files in a directory without the marker.
