# Plan 05 — Backend, evidence store, verdict, approval, replay (elapsed hours 6–18)

**Owner:** Person C  **Depends on:** plan-03 (tools, executor, fixtures); plan-04 for live integration  **Unblocks:** plan-06, plan-07, plan-08 · **Gate:** G3

## Goal

A Node 20 + Express + TypeScript + `better-sqlite3` service on `127.0.0.1:3000` that owns run state, evidence, approvals, SSE, the report and the **only** verdict. It replaces `stub_backend.py` with the same routes. It enforces approval and replay rules from stored state, never from client headers.

## Layout

```text
changeguard-ai/backend/
├── package.json         # express, better-sqlite3, zod, nanoid; dev: typescript, tsx, vitest, supertest, @types/*
├── .env.example         # WORK_ROOT, INTERNAL_API_KEY, WXO_API_ENDPOINT, WXO_AGENT_ID, WXO_AUTH, WXO_API_KEY, WXO_TOKEN,
│                        # MISSION_CONTROL_URL, EXECUTOR_URL, REPLAY_RUN_ID
├── db/schema.sql
├── src/
│   ├── server.ts        # Express app bound to 127.0.0.1:3000
│   ├── workroot.ts      # marker / origin checks; HEAD; baseline Jest run
│   ├── db.ts            # open DB, run schema, typed queries
│   ├── events.ts        # append event, update derived rows, emitter for SSE
│   ├── verdict.ts       # computeVerdict, linking, closure (pure functions)
│   ├── runs.ts          # create run, baseline, analysis, finish
│   ├── approvals.ts     # approve, reject, call executor
│   ├── wxo.ts           # Orchestrate client
│   ├── report.ts        # JSON + Markdown report from rows
│   ├── replay.ts        # read-only replay stream
│   └── routes/{public.ts, internal.ts}
└── test/                # vitest + supertest
```

The internal router checks `X-Internal-Key` with a constant-time compare. The server refuses to start if `WORK_ROOT` fails the checks in CONTRACTS.md §2.

## Schema (`db/schema.sql`)

```sql
CREATE TABLE IF NOT EXISTS runs (
  id TEXT PRIMARY KEY, jira_id TEXT NOT NULL, requirement_text TEXT NOT NULL,
  base_ref TEXT NOT NULL, head_ref TEXT NOT NULL, head_commit TEXT NOT NULL,
  source TEXT NOT NULL,                                  -- bob | mission_control
  status TEXT NOT NULL, verdict TEXT, reason_codes TEXT,
  thread_id TEXT, is_replay INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL, analysis_ms INTEGER, total_ms INTEGER
);
CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT, run_id TEXT NOT NULL REFERENCES runs(id),
  stage TEXT NOT NULL, tool TEXT, status TEXT NOT NULL, payload_json TEXT NOT NULL, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS risks (
  run_id TEXT NOT NULL REFERENCES runs(id), id TEXT NOT NULL, severity TEXT NOT NULL,
  hazard TEXT, rule_id TEXT, file_path TEXT, line_num INTEGER, message TEXT,
  linked_test TEXT, confirmed INTEGER NOT NULL DEFAULT 0,
  closed INTEGER NOT NULL DEFAULT 0, closed_evidence TEXT,  -- JSON: {test, scan_tree}
  PRIMARY KEY (run_id, id)
);
CREATE TABLE IF NOT EXISTS test_executions (
  id INTEGER PRIMARY KEY AUTOINCREMENT, run_id TEXT NOT NULL REFERENCES runs(id),
  phase TEXT NOT NULL,                                   -- baseline | red_proof | reverify
  commit_sha TEXT, command TEXT, test_name TEXT,
  passed INTEGER, failed INTEGER, total INTEGER, exit_code INTEGER,
  per_test_json TEXT, proof_valid INTEGER, proof_status TEXT, invalid_reason TEXT,
  path_json TEXT, top_src_frame TEXT, base_comparison_json TEXT,
  scan_ok INTEGER, scan_tree TEXT, raw_output TEXT, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS proposals (
  id TEXT PRIMARY KEY, run_id TEXT NOT NULL REFERENCES runs(id),
  diff BLOB NOT NULL, diff_sha256 TEXT NOT NULL, head_commit TEXT NOT NULL,
  files_json TEXT NOT NULL, rationale TEXT, check_ok INTEGER NOT NULL, changed_lines INTEGER,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS approvals (
  id TEXT PRIMARY KEY, run_id TEXT NOT NULL REFERENCES runs(id),
  proposal_id TEXT NOT NULL REFERENCES proposals(id),
  approver_name TEXT NOT NULL, diff_sha256 TEXT NOT NULL, head_commit TEXT NOT NULL,
  created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL,
  used INTEGER NOT NULL DEFAULT 0, used_at INTEGER
);
CREATE TABLE IF NOT EXISTS rejections (
  run_id TEXT PRIMARY KEY REFERENCES runs(id), approver_name TEXT NOT NULL, reason TEXT, created_at INTEGER NOT NULL
);
```

Store the diff as the exact bytes received (BLOB), and hash those bytes.

## Behaviour

### Creating a run (`POST /api/runs`)
1. Validate with zod: `jira_id`, `requirement_text`, `base_ref`, `head_ref`, optional `source`. Refuse 409 `INVALID_STATE` if another run is `analyzing` or `applying`.
2. Check `WORK_ROOT`: marker, origin, `git rev-parse HEAD == git rev-parse <head_ref>`, `git status --porcelain -- src` empty. Otherwise 409 `HEAD_CHANGED` or `WORKTREE_DIRTY` (ask for a reset).
3. Insert the run as `created` with `head_commit`; id `run_YYYYMMDD_NNNN`. Respond at once `{ run_id, mission_control_url }`.
4. In the background:
   - **Baseline** (first): `npx jest --config jest.sandbox.config.js --json --outputFile=<tmp> --testPathIgnorePatterns tests/generated` in `WORK_ROOT` via `execFile`, scrubbed env, 120 s. Store a `baseline` row with commit, command, passed, failed, total, exit code, raw output; post a `baseline` event.
   - **Analysis**: set `analyzing`; call Orchestrate with the analysis message (CONTRACTS.md §13).
5. When Orchestrate returns, parse the last JSON object in the reply:
   - `analysis_done` **and** a stored proposal with `check_ok = 1` for this run (from the DB, not the reply's id) → `awaiting_approval`.
   - `no_proof`, or no stored proposal → `done`.
   - Error or 3-minute timeout → `failed`.
   - Compute the verdict, set `analysis_ms`, emit a verdict event.

### Appending evidence (`POST /internal/runs/:id/events`)
Validate the envelope against CONTRACTS.md §5; reject unknown stages. Insert into `events`. Derived rows:
- `risks` → upsert findings, `confirmed = 0`.
- `red_proof` → insert `test_executions` (phase `red_proof`). If `proof_valid`: **link** every Critical/High finding whose `file_path` is in the test's path; mark findings `confirmed = 1` where `top_src_frame` equals their `file:line`.
- `reverify_report` → insert `test_executions` (phase `reverify`) with `scan_ok`, `scan_tree`. Then **close** a Critical/High finding only if its linked test's `r.result == "passed"` **and** `scan_ok` is true **and** no finding with the same `(hazard, file_path)` appears in `findings_after`; record `closed_evidence = {test, scan_tree}`. Then compute the verdict, set `done` (or `failed` if the event status is `error`), set `total_ms`.

Push every event to SSE subscribers of that run.

### Verdict (`verdict.ts`)
Port CONTRACTS.md §8 literally, including `r.result()` with `passed`/`failed`/`missing`. Return reason codes. 100% unit-test coverage on this file.

### Approve (`POST /api/runs/:id/approve`)
Body: `approver_name`, `proposal_id`, `sha256` (full, as displayed).
1. Load the run from the DB. Refuse 409 `INVALID_STATE` unless `status = awaiting_approval` and `is_replay = 0`. Ignore any client header about replay.
2. `proposal_id` must belong to the run (404). `sha256` must equal the stored `diff_sha256` exactly (409 `APPROVAL_HASH_MISMATCH`). The proposal's `head_commit` must equal the run's `head_commit` (409 `HEAD_CHANGED`).
3. Insert approval: id `apr_` + nanoid; copy `diff_sha256`, `head_commit`; `expires_at = now + 600000`.
4. Set `applying`; post a `human_gate` event.
5. Call `POST ${EXECUTOR_URL}/apply` with `X-Internal-Key` and `{ run_id, approval_id }`, 180 s timeout. On an executor error, set `failed`, keep the verdict, post an error event with the code.
6. Respond `{ approval_id }` once the approval is written; the UI follows SSE.

### Reject (`POST /api/runs/:id/reject`)
Same state checks as approve. Insert into `rejections`, post a `human_gate` event with `rejected: true`, set `rejected`. Files untouched.

### Internal approval routes
- `GET /internal/approvals/:id` → `{ id, run_id, used, expires_at, diff_sha256, head_commit, diff }` (diff as base64 of the stored bytes).
- `POST /internal/approvals/:id/consume` → `UPDATE approvals SET used=1, used_at=? WHERE id=? AND used=0 AND expires_at>?`; one row → 200; else 409 `APPROVAL_USED` or 410 `APPROVAL_EXPIRED`.
- `POST /internal/runs/:id/proposals` → store bytes and fields; return `{ proposal_id }` (`prop_` + nanoid).

### SSE (`GET /api/runs/:id/stream`)
`text/event-stream`, `cache-control: no-cache`. Send stored events in order (`event: stage`), the current verdict (`event: verdict`), then live events; heartbeat every 15 s.

### Report (`GET /api/runs/:id/report?format=json|md`)
Only from rows: run and commits; verdict history with reason codes; phases with durations; baseline and final counts with exit codes; the path; proof status with raw output excerpt and base comparison (if recorded); findings with confirmation and closure evidence; proposal full hash and files; approval (name, time, expiry) labelled "typed name, not authenticated"; metrics; the disclosure block from CONTRACTS.md §14; `REPLAY` marking if applicable. Markdown downloads as `changeguard-<run_id>.md`.

### Replay (`GET /api/replay/:id`)
Read-only SSE: first `event: replay` with `{ original_run_id, recorded_at }`, then the stored events in order with real gaps capped at 4 s, each with `"replay": true`. No DB writes. Nothing in replay calls a mutating route; mutating routes decide from DB state only.

### Reset (`POST /api/demo/reset`)
Runs `changeguard-ai/scripts/reset-demo.sh` (plan-08), which refuses any directory without the marker. Marks any `analyzing`/`applying` run `failed`. Returns `{ ok, head }`.

### Orchestrate client (`wxo.ts`)
- `POST ${WXO_API_ENDPOINT}/v1/orchestrate/${WXO_AGENT_ID}/chat/completions` (local Developer Edition: check whether the base needs `/api`). Headers `Authorization: Bearer <token>`, `Content-Type: application/json`. Body `{ "stream": false, "messages": [{ "role": "user", "content": "<analysis message>" }] }`. Timeout 3 min.
- Token: `WXO_AUTH=iam` exchanges `WXO_API_KEY` at the IBM Cloud IAM token endpoint and caches until 5 min before expiry; `WXO_AUTH=static` uses `WXO_TOKEN`. Use the method that worked in plan-01.
- Save `thread_id` if present (informational only).

## Bob — Plan mode

```text
Read AGENTS.md, plans/CONTRACTS.md and plans/plan-05-backend.md.
Plan changeguard-ai/backend exactly as in plan-05: modules, each route's validation and state checks, the schema,
verdict.ts as a pure port of CONTRACTS.md §8, linking and closure, replay enforcement from DB state, and every
test listed under Acceptance checks. Do not write files yet.
```

## Bob — Agent mode

```text
Implement the approved plan-05 plan in changeguard-ai/backend with Node 20, Express, TypeScript, better-sqlite3,
zod, vitest and supertest. Write verdict.ts and its tests first. Mock Orchestrate and the executor in unit tests.
Route paths, JSON fields, error codes and status codes must match plans/CONTRACTS.md exactly.
npm scripts: dev (tsx watch), test, start. Run the tests and the acceptance checks; show the output.
```

## Acceptance checks (gate G3)

Unit and API tests (vitest):
- [ ] Verdict: VALID proof before re-verify → BLOCKED; no valid proof → NEEDS_REVIEW.
- [ ] Verdict: good re-verify (exit 0, proof test passed, totals match, scan ok, risks closed) → PASSED with reason codes.
- [ ] Verdict: proof test missing from re-verify (deleted) → not PASSED (`PROOF_TEST_MISSING`).
- [ ] Verdict: proof test failing in re-verify → BLOCKED. Another test failing → NEEDS_REVIEW.
- [ ] Verdict: `scan_ok = false` → not PASSED (`SCAN_FAILED`). Baseline not green → not PASSED.
- [ ] Closure: a finding with a passing linked test but still present in `findings_after` stays open. A finding absent from a scan with `scan_ok = false` stays open.
- [ ] Approve: wrong state 409; replayed run (`is_replay = 1`) 409; wrong proposal 404; hash differs by one character 409; HEAD mismatch 409; good approval → executor called once.
- [ ] Approve with spoofed or missing replay headers behaves identically (headers ignored).
- [ ] Consume: second call 409; expired 410; two concurrent calls → exactly one succeeds.
- [ ] Reject → `rejected`; files untouched.
- [ ] `POST /api/runs` with dirty `src` or moved HEAD → 409.
- [ ] Internal routes without the key → 401.
- [ ] SSE: a late subscriber gets all past events, then live ones.

Integration (real tools and executor from plan-03, Orchestrate mocked by a script that replays `fixtures/hero-run.jsonl` into `/internal/runs/:id/events`):
- [ ] `POST /api/runs` → baseline event with real counts → BLOCKED → `awaiting_approval`.
- [ ] Approve with the full hash → executor applies → re-verify green → `done`, PASSED, reason codes include `PROOF_TESTS_PASS`, `TOTALS_MATCH`, `SCAN_OK`.
- [ ] Report JSON and Markdown contain only stored values and the disclosure block.

Live (with plan-04): one run from `POST /api/runs` to PASSED with no terminal use after the first call.

## Do not

- Let a model reply set a verdict, or set any status except through the parsed `phase`.
- Send approval data to Orchestrate.
- Expose `/internal/*` or the executor beyond `127.0.0.1`.
- Trust client headers for any permission decision.
