# Plan 01 — Event rules, environment and auth gate (elapsed hours 0–2)

**Owner:** Person A  **Depends on:** nothing  **Unblocks:** every other plan · **Gate:** G0

## Goal

By elapsed hour 2: the event rules and cutoff are confirmed, every laptop has the toolchain, the ADK talks to the Orchestrate instance you will demo on, and you have **proven** how Orchestrate reaches your MCP server with a credential. Build nothing else on an assumed auth path.

## Why this comes first

The agent tools execute code. The endpoint must never be reachable without a credential. IBM's remote-toolkit docs say `--app-id` accepts only `key_value` connections, exposed to the MCP server as environment variables; it isn't documented that a value arrives as a request header at a remote server. So you test it with a ping server and read the headers.

## Steps

### 0. Event rules and access (first 30 min, before any setup)

- [ ] Exact cutoff with time zone, from the submission platform (stated as 23 November). Write it at the top of the README.
- [ ] Required submission fields, video length limit, repository visibility rules.
- [ ] Whether IBM Bob and watsonx Orchestrate must be used live in the demo, at build time, or both.
- [ ] Whether a recorded fallback is allowed during judging.
- [ ] Every member signs in to IBM Bob and to the Orchestrate instance you'll demo on.

If any answer is unknown or access fails, message the organizers immediately and record the question and time in `docs/evidence/01/rules.md`. Don't claim eligibility for a path you haven't confirmed.

Reference for feasibility (not proof that your setup works): IBM's tutorial on using Bob to build watsonx Orchestrate agents with MCP tools, https://developer.ibm.com/tutorials/build-agents-mcp-tools-watsonx-orchestrate-using-bob/

### 1. Toolchain (every laptop, 20 min)

| Item | Version | Check |
| --- | --- | --- |
| Python | 3.11 or 3.12 | `python --version` |
| Node.js | 20 LTS | `node -v && npm -v` |
| Git | recent | `git --version` |
| uv | latest | `uvx --version` |
| IBM Bob | 2.x | mode picker shows Agent, Plan, Ask |
| Docker | only for option A | `docker info` |
| ngrok or Cloudflare Tunnel | only for options B/C | `ngrok version` |

```bash
mkdir -p changeguard-workspace/changeguard-ai/{tools,wxo-agents,backend,frontend,scripts,docs/evidence}
cd changeguard-workspace
cp -r <this folder> plans && cp plans/AGENTS.md .
python -m venv .venv && source .venv/bin/activate      # Windows: .\.venv\Scripts\Activate.ps1
pip install ibm-watsonx-orchestrate "fastmcp>=2,<3" uvicorn httpx pytest
pip freeze | grep -Ei "orchestrate|fastmcp" > changeguard-ai/tools/requirements.lock.txt
```

### 2. Connect the ADK (10 min)

```bash
orchestrate env add -n bobstorm -u "<service instance URL>"     # pick the auth type the CLI asks for (IBM Cloud or AWS)
orchestrate env activate bobstorm --api-key "<API key>"
orchestrate env list        # bobstorm active
orchestrate agents list     # no auth error
orchestrate models list     # write the strongest instruct model id into the README
```

### 3. Bob MCP for building (10 min)

Create `changeguard-workspace/.bob/mcp.json` (committed, no secrets):

```json
{
  "mcpServers": {
    "wxo-docs": { "url": "https://developer.watson-orchestrate.ibm.com/mcp" }
  }
}
```

Add `wxo-mcp` (needs an absolute `WXO_MCP_WORKING_DIRECTORY`) in Bob's **global** MCP settings on each laptop, not in the committed file:

```json
"wxo-mcp": {
  "command": "uvx",
  "args": ["--with", "ibm-watsonx-orchestrate", "ibm-watsonx-orchestrate-mcp-server"],
  "env": { "WXO_MCP_WORKING_DIRECTORY": "/ABSOLUTE/PATH/changeguard-workspace/changeguard-ai/wxo-agents" }
}
```

Check: in Bob Ask mode, *"Using wxo-docs, what is the ADK command to add a remote MCP toolkit?"* → answer names `orchestrate toolkits add --kind mcp --url --transport`.

### 4. The auth gate (60 min)

1. Copy `plans/starter/tools/ping_server.py` to `changeguard-ai/tools/ping_server.py`. It has one tool, `ping`, and logs every request's headers.
2. Choose where Orchestrate runs, then try the options **in this order** and stop at the first that works:

| Option | Setup | Protection |
| --- | --- | --- |
| **A. Local Developer Edition** | `orchestrate server start ...` per IBM docs; run ping with `HOST=0.0.0.0 PORT=8000`; import with URL `http://host.docker.internal:8000/mcp` | Bind or firewall so only the Docker bridge can reach port 8000; nothing is public |
| **B. SaaS + tunnel + credential header** | `ngrok http 8000`; create a key_value connection; import with `--app-id`; check the ping log for a header carrying your value | Server rejects requests without that header |
| **C. SaaS + tunnel + IP restriction** | Tunnel plan that allowlists Orchestrate's egress IPs | Tunnel refuses everyone else |

Import and test the ping toolkit (replace URL and connection):

```bash
orchestrate connections add -a changeguard_ping_conn                      # only for option B
orchestrate connections configure -a changeguard_ping_conn --env draft --type team --kind key_value
orchestrate connections set-credentials -a changeguard_ping_conn --env draft -e "MCP_CREDENTIAL=$(python -c 'import secrets;print(secrets.token_hex(16))')"

orchestrate toolkits add --kind mcp --name changeguard_ping \
  --description "Auth gate ping" --url "<URL>/mcp" --transport streamable_http \
  --tools "ping" [--app-id changeguard_ping_conn]

orchestrate tools list -v            # shows changeguard_ping:ping
```

Then create a throwaway agent with tool `changeguard_ping:ping`, call it with `orchestrate chat ask --agent-name <name> "call ping with hello"`, and read the ping server log.

3. Write the decision into `changeguard-ai/README.md`: option chosen, URL pattern, how the credential is checked, and the exact remove → add → re-import → re-deploy sequence for toolkit changes.
4. **If nothing works by hour 2, use option A.** An unauthenticated public tunnel is not allowed.

### 5. Clean up

Delete the ping log (it may contain credential values) and remove the throwaway agent and toolkit:

```bash
orchestrate agents remove --name <throwaway>     # check exact syntax with --help
orchestrate toolkits remove --name changeguard_ping
```

## Bob — Agent mode (optional helper)

```text
Read plans/plan-01-environment-auth-gate.md and plans/CONTRACTS.md.
Create changeguard-ai/README.md with sections: Setup, Auth option (leave TODO), Toolkit update sequence,
Model id (TODO), Environment variables (from CONTRACTS.md section 2), and .env.example files for
tools/ and backend/ with placeholder values only. Do not create any other files.
```

## Acceptance checks (gate G0)

- [ ] Cutoff with time zone, submission fields and IBM-use requirements recorded in the README (or the open question and who was asked).
- [ ] `orchestrate env list` shows the demo environment active; `orchestrate models list` works.
- [ ] Orchestrate called `ping` successfully; log saved (with secrets redacted) to `docs/evidence/01/`.
- [ ] An unauthenticated request to the ping endpoint fails (option A: unreachable from outside; B: 401; C: refused by tunnel).
- [ ] README records the auth option and the toolkit update sequence.
- [ ] `.bob/mcp.json` committed with no secrets; Bob can query `wxo-docs`.

## Do not

- Build the real tool server before this gate passes.
- Commit `.env`, tunnel URLs, API keys or the ping log.
