# Plan 08 — Hardening, replay, metrics, rehearsal (elapsed hours 18–36)

**Owner:** Person D leads; Person A is demo commander; everyone rehearses  **Depends on:** plans 01–07  **Unblocks:** submission · **Gate:** G5

## Goal

The demo resets safely in seconds, has run live end to end five times in a row, has an honest labelled replay, and every number we say was measured and logged with its sample size.

## Steps

### 1. Safe reset script (elapsed hour 18)

`changeguard-ai/scripts/reset-demo.sh`:

```bash
#!/usr/bin/env bash
set -euo pipefail
: "${WORK_ROOT:?set WORK_ROOT}"
FIXTURE="$(cd "$(dirname "$0")/../../target-enterprise-app" && pwd)"
WORK="$(cd "$WORK_ROOT" && pwd)"

# Refuse anything that isn't the disposable checkout
[ "$WORK" != "$FIXTURE" ] || { echo "refusing: WORK_ROOT is the fixture"; exit 2; }
grep -qx 'repo_id=product-pricing-service' "$WORK/.changeguard-disposable" || { echo "refusing: no disposable marker"; exit 2; }
ORIGIN="$(git -C "$WORK" remote get-url origin)"
[ "$(cd "$ORIGIN" 2>/dev/null && pwd)" = "$FIXTURE" ] || { echo "refusing: origin is not the fixture"; exit 2; }
( flock -n 9 || { echo "refusing: checkout is locked"; exit 3; }
  cd "$WORK"
  git checkout -q -f feature/promo-null-discount
  git reset -q --hard demo-pr
  git clean -fdq -e .changeguard-disposable -e .changeguard -e jest.sandbox.config.js -e node_modules
  git rev-parse --short HEAD
) 9>"$WORK/.changeguard.lock"
```

On macOS without `flock`, install it (`brew install flock`) or use the Python lock helper from plan-03. `chmod +x`. Wire `POST /api/demo/reset` (plan-05) to it.

Checks: `time scripts/reset-demo.sh` under 3 s; `git -C demo-work status --porcelain` empty afterwards; running it with `WORK_ROOT` set to the fixture or to `/tmp` exits 2 and changes nothing.

### 2. Start and stop scripts (elapsed hour 18)

`scripts/start-demo.sh` starts, in order, with logs in `logs/`: backend (127.0.0.1:3000), executor (127.0.0.1:8002), agent MCP (:8000), reviewer MCP (127.0.0.1:8001), tunnel if auth option B or C, frontend (:4200). It waits up to 30 s for each port and prints a checklist with the first failing service. `scripts/stop-demo.sh` stops them all.

### 3. Rehearsal log (elapsed hours 24–30)

Run reset + full live flow (Bob opening → PASSED — within tested scope) **five times in a row**. After each run append a row to `docs/evidence/08/rehearsal.md`:

| # | Time | Run id | Baseline (passed/failed/exit) | Time to BLOCKED (s) | Final (passed/failed/exit) | Verdict | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- |

A failure resets the consecutive count to zero. Fix the cause before continuing. Keep every row, including failures; reliability is clean runs / total runs.

### 4. Manual review trial (20 min, any time after G1)

Give one teammate who hasn't seen the code the diff (`git diff demo-base...demo-pr`) and the repo. Ask: "Would anything break if this merged? Where?" Time until they name the billing calculator, stopping at 30 minutes. Record minutes and whether they found it. Quote it only as "one reviewer, one trial (anecdotal)".

### 5. Metrics (elapsed hour 30)

| Metric | Value to fill | Source |
| --- | --- | --- |
| Median time to BLOCKED | `<median> s (n = 5)` | rehearsal.md |
| Baseline → final | `<b_passed> → <f_passed> passed, 0 failed, exit 0` | report JSON |
| Proven regressions | `<count>` VALID proof(s) | report JSON |
| Inconclusive attempts | `<count>` (with reasons) | report JSON |
| Manual trial | `<minutes> min, found: yes/no (n = 1)` | step 4 |
| Reliability | `<clean>/<total>` runs | rehearsal.md |

Don't quote coverage gains or business value. Replace every placeholder or delete the metric.

### 6. Record the replay run (after freeze)

Pick the cleanest live run after the freeze. Set `REPLAY_RUN_ID`. Check `/replay/<id>`: the banner stays visible; original timestamps in the evidence drawer; approve is disabled; a forced approve request with no header, a fake header, or a real-looking header is refused by the server with `INVALID_STATE`.

### 7. Backup video

Screen-record one clean live run with narration, under the platform's length limit (target 3:00). Save it on the demo laptop's desktop and a USB stick. Play it once with Wi-Fi off.

### 8. Script timing

Rehearse the 3-minute script with a stopwatch, twice. If over time, cut words, not steps.

### 9. Final checks (elapsed hour 32)

- Secret scan: `git grep -nIiE "api[_-]?key|token|secret|ngrok|trycloudflare" -- ':!*.md'` shows nothing sensitive; `.env` files are gitignored.
- Record the demo-freeze commit, the replay run id and the backup video's SHA-256 in `docs/evidence/08/freeze.md`.
- Tag `demo-freeze`.
- Print the demo commander card from the blueprint.

## Freeze rules

- No new feature after G4.
- No tool schema change after the first of the five rehearsal runs.
- No dependency upgrades in the final five hours.
- Only the demo commander merges in the final five hours.

## Bob — Agent mode (scripts)

```text
Read AGENTS.md, plans/CONTRACTS.md and plans/plan-08-hardening-rehearsal.md.
Create changeguard-ai/scripts/reset-demo.sh exactly as written, plus start-demo.sh and stop-demo.sh as described
in step 2. start-demo.sh waits for ports 3000, 8002, 8000, 8001, 4200 (30 s each) and names the first that fails.
Use only bash, curl and standard tools. Do not change any other file. Then run the reset checks in step 1,
including the two refusal cases, and show the output.
```

## Acceptance checks (gate G5)

- [ ] Reset under 3 s; clean tree; refuses the fixture path and a path without the marker.
- [ ] Five consecutive live runs, Bob opening → PASSED — within tested scope, all logged with real counts and exit codes.
- [ ] Median time to BLOCKED and reliability recorded with n.
- [ ] Manual trial recorded and labelled anecdotal.
- [ ] Replay checked, including forced approve requests refused by the server.
- [ ] Backup video plays offline and is within the length limit.
- [ ] Script timed twice within 3:00.
- [ ] Secret scan clean; freeze record written; `demo-freeze` tag exists.
- [ ] `SUBMISSION.md` filled with measured values and uploaded before the cutoff.
