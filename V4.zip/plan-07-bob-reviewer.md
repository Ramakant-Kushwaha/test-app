# Plan 07 — IBM Bob reviewer mode and opening (elapsed hours 12–24)

**Owner:** Person A  **Depends on:** plan-03 (reviewer MCP on 127.0.0.1:8001), plan-05 (backend)  **Unblocks:** plan-08 · **Gate:** G4

## Goal

The demo opens in Bob. A developer asks whether PRICE-142 is safe to merge; Bob calls `start_changeguard_run` and prints the Mission Control link within 10 seconds. Bob can only start and watch runs. It has no tool that writes files, runs code or applies patches. Bob's build-time use (Plan → Agent for plans 02, 03, 05, 06) is captured as evidence.

## Steps

### 1. Connect Bob to the reviewer endpoint
`changeguard-workspace/.bob/mcp.json` (committed; no secrets; the reviewer server is localhost-only):

```json
{
  "mcpServers": {
    "wxo-docs": { "url": "https://developer.watson-orchestrate.ibm.com/mcp" },
    "changeguard-reviewer": { "url": "http://localhost:8001/mcp" }
  }
}
```

If Bob's MCP settings panel writes a different layout for remote servers (for example a `type` field), use what the panel writes. Confirm that only `start_changeguard_run` and `get_run_status` appear under `changeguard-reviewer`.

### 2. Create the ChangeGuard Reviewer mode
Bob mode settings (gear icon → +): name **ChangeGuard Reviewer**; MCP access on; file-edit and command tools off. Instructions:

```text
You are ChangeGuard Reviewer. You help a developer decide whether a change is safe to merge.
1. When asked whether a change or Jira story is safe, call start_changeguard_run with:
   jira_id = the Jira id the developer named (for the demo: PRICE-142),
   requirement_text = "Promotional items may have no discount code. Billing must tag a line with no discount code as NONE.",
   base_ref = "demo-base", head_ref = "demo-pr".
2. Reply in at most two sentences: you started a ChangeGuard run to check changed contract fields and untouched
   runtime consumers; give the run id and the Mission Control link. Don't state test counts yourself;
   Mission Control shows the measured baseline.
3. If the tool returns HEAD_CHANGED or WORKTREE_DIRTY, say the demo checkout needs a reset and stop.
4. If asked for status, call get_run_status and report the phase, the verdict, and any untouched consumers with
   file and line. Call static findings hypotheses unless the verdict says a proof is valid.
5. Never say a change is safe to merge. PASSED means the recorded tests and scans passed within this run's scope.
6. Never edit files or run commands.
```

Save a copy in `changeguard-workspace/.bob/reviewer-instructions.md`.

### 3. Rehearse the opening

```text
Developer: Is PRICE-142 safe to merge?
Bob:       I've started ChangeGuard run run_… to check changed contract fields and untouched runtime
           consumers: http://localhost:4200/runs/run_…
Presenter: "CI is green on this branch. Let's see what those tests never exercised."  [clicks the link]
```

Time it 5 times from Enter to link. Target: under 10 s. Record the times.

### 4. Record the fallback clip
Record a 15-second clip of a clean opening with a visible "Recorded" label. Save it to `docs/evidence/07/bob-opening.mp4` and the demo laptop's desktop.

### 5. Build-time evidence
Export or screenshot Bob sessions for plans 02, 03, 05 and 06 (Plan → Agent) into `docs/evidence/bob/`, without credentials. Link them from the README section "How we used IBM Bob" and from `SUBMISSION.md`.

## Acceptance checks

- [ ] Bob lists exactly 2 tools for `changeguard-reviewer`.
- [ ] "Is PRICE-142 safe to merge?" creates a run with `source = bob` and a working link, 5/5 times; median time recorded.
- [ ] With a dirty checkout, Bob reports that a reset is needed and creates nothing.
- [ ] "Apply the fix" or "Is it safe to merge?" after PASSED: Bob refuses to apply and doesn't claim merge safety.
- [ ] Fallback clip recorded and labelled.
- [ ] Bob evidence folder and README section exist.

## Do not

- Connect Bob to the agent MCP (:8000) or the executor.
- Debug Bob configuration on stage; use the labelled clip.
