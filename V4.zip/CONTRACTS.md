# CONTRACTS.md — frozen interfaces

Frozen at elapsed hour 9. Changes need the demo commander's approval, a version note at the bottom, and an update to every plan that uses the changed item.

---

## 1. Fixed names and values

| Item | Value |
| --- | --- |
| Fixture repository (source, never modified at runtime) | `target-enterprise-app/` (package `product-pricing-service`) |
| Disposable checkout (all runtime work happens here) | `demo-work/`, cloned from the fixture by `scripts/make-demo-work.sh` |
| Disposable marker | `demo-work/.changeguard-disposable` containing `repo_id=product-pricing-service` |
| Baseline branch / tag | `main` / `demo-base` |
| Candidate branch / tag | `feature/promo-null-discount` / `demo-pr` |
| Jira id | `PRICE-142` |
| Requirement text | `Promotional items may have no discount code. Billing must tag a line with no discount code as NONE.` |
| Expected baseline (target, not a promise) | 18 passed, 0 failed, exit 0 |
| Expected final (target, not a promise) | 19 passed, 0 failed, exit 0 |
| Hero hazard | `src/billing/InvoiceTaxCalculator.ts:8` |
| Event name | `billing.line` |
| Agent MCP | `http://<host>:8000/mcp` (streamable HTTP) |
| Reviewer MCP | `http://localhost:8001/mcp` (streamable HTTP) |
| Executor | `http://127.0.0.1:8002/apply` (plain HTTP, not MCP) |
| Backend | `http://127.0.0.1:3000` |
| Mission Control | `http://localhost:4200/runs/<run_id>` |
| Orchestrate toolkit name | `changeguard_mcp` |
| Primary Orchestrate agent | `changeguard_analyst` (single agent; specialists are optional) |
| Approval lifetime | 10 minutes |
| Patch budget | at most 40 changed lines, only under `src/` |
| Generated test pattern | `^[a-z0-9-]{3,48}$`, file `tests/generated/<name>.test.ts` |
| Generated test limits | 60 s, 1 worker, scrubbed env, network and child processes blocked (§9) |

Counts on screen are always the counts the runner reported. 18 and 19 are rehearsal targets.

## 2. Environment variables

| Variable | Used by | Meaning |
| --- | --- | --- |
| `WORK_ROOT` | tools, executor, backend | Absolute path of `demo-work/` (must contain the marker) |
| `BACKEND_URL` | tools, executor | `http://127.0.0.1:3000` |
| `INTERNAL_API_KEY` | tools, executor, backend | Shared key for `/internal/*` and the executor |
| `AGENT_MCP_CREDENTIAL` | agent MCP | Checked on each request (auth option B only) |
| `WXO_API_ENDPOINT`, `WXO_AGENT_ID`, `WXO_AUTH`, `WXO_API_KEY`, `WXO_TOKEN` | backend | Orchestrate chat endpoint and credentials |
| `MISSION_CONTROL_URL` | backend | `http://localhost:4200` |

Every process refuses to start if `WORK_ROOT` lacks the marker or its `origin` isn't the fixture path.

## 3. Stage keys (the only stage vocabulary)

| # | Key | Phase shown | Produced by |
| --- | --- | --- | --- |
| 0 | `baseline` | Intake | backend (Jest on the candidate commit, generated tests excluded) |
| 1 | `requirement` | Intake | `get_git_diff` |
| 2 | `diff` | Impact | `get_git_diff` |
| 3 | `blast_radius` | Impact | `analyze_blast_radius` |
| 4 | `risks` | Impact | `run_security_rules` |
| 5 | `test_gen` | Proof | `write_and_run_tests` |
| 6 | `red_proof` | Proof | `write_and_run_tests` |
| 7 | `fix_proposal` | Approval | `submit_patch_proposal` |
| 8 | `human_gate` | Approval | backend (approve / reject) |
| 9 | `reverify_report` | Verify | executor |

Phases in order: `Intake`, `Impact`, `Proof`, `Approval`, `Verify`.

## 4. Run statuses and verdicts

`created` → `analyzing` → `awaiting_approval` → `applying` → `done`
Side exits: `analyzing → failed`; `analyzing → done` (no valid proof → NEEDS_REVIEW); `awaiting_approval → rejected`; `applying → failed`.

Verdicts: `BLOCKED`, `NEEDS_REVIEW`, `PASSED` (always displayed as **PASSED — within tested scope**). PASSED only in `done` after `reverify_report`.

## 5. Event envelope

```json
{
  "run_id": "run_20261120_0001",
  "stage": "red_proof",
  "status": "started | done | error",
  "tool": "write_and_run_tests",
  "at": 1763620000000,
  "payload": { }
}
```

Every command result in a payload carries `command`, `exit_code`, `duration_ms` and `raw_output` (capped at 64 KB).

| Stage | Payload fields |
| --- | --- |
| `baseline` | `commit`, `command`, `passed`, `failed`, `total`, `exit_code`, `raw_output` |
| `requirement` | `acceptance_criteria[]` |
| `diff` | `base_commit`, `head_commit`, `changed_files[]`, `hunks[]`, `changed_symbols[]`, `changed_fields[]` |
| `blast_radius` | `nodes[] {id, file, kind: changed|dependency|consumer|other}`, `edges[] {from, to, kind: import|event, label}`, `paths[] {target_file, files[]}` (changed file → … → consumer), `untouched_consumers[] {file, line, snippet, hazard}`, `detection: "rules"` |
| `risks` | `findings[] {id, rule_id, hazard, severity, file, line, message, status: "hypothesis"}`, `scan_ok`, `scan_commit` |
| `test_gen` | `test_name`, `test_code`, `target_file`, `path_files[]` |
| `red_proof` | `test_name`, `passed`, `failed`, `total`, `exit_code`, `messages[]`, `top_src_frame`, `path_files_hit {file: statements}`, `path_reached`, `failure_kind: thrown|assertion|setup|timeout|none`, `proof_valid`, `proof_status: VALID|INCONCLUSIVE`, `invalid_reason`, `base_comparison` (optional: `{commit, failed, top_src_frame}`), `raw_output` |
| `fix_proposal` | `proposal_id`, `files[]`, `sha256` (full), `head_commit`, `check_ok`, `changed_lines` |
| `human_gate` | `approval_id` or `rejected: true`, `approver_name`, `sha256` (full), `head_commit`, `expires_at` |
| `reverify_report` | `head_commit_before`, `applied_files[]`, `passed`, `failed`, `total`, `exit_code`, `per_test[] {file, name, status}`, `scan_ok`, `scan_tree`, `findings_after[]`, `raw_output` |

Verdict event (backend only): `{ "run_id", "verdict", "reason_codes": [], "baseline": {passed, failed, total, exit_code}, "final": {passed, failed, total, exit_code}, "analysis_ms", "total_ms" }`.

## 6. Tool schemas

### Agent MCP (port 8000) — Orchestrate only

| Tool | Arguments | Returns |
| --- | --- | --- |
| `get_git_diff` | `run_id`, `base_ref = "demo-base"`, `head_ref = "demo-pr"`, `acceptance_criteria: list[str]` | the `diff` payload |
| `analyze_blast_radius` | `run_id`, `changed_files: list[str]`, `changed_fields: list[str]` | the `blast_radius` payload |
| `run_security_rules` | `run_id` | the `risks` payload |
| `write_and_run_tests` | `run_id`, `test_name`, `test_code`, `target_file` | the `red_proof` payload (the tool looks up `path_files` from the stored blast radius; the agent doesn't supply it) |
| `submit_patch_proposal` | `run_id`, `unified_diff`, `rationale` | `proposal_id`, `files`, `sha256`, `check_ok`, `changed_lines` |

### Reviewer MCP (port 8001) — Bob only

| Tool | Arguments | Returns |
| --- | --- | --- |
| `start_changeguard_run` | `jira_id`, `requirement_text`, `base_ref = "demo-base"`, `head_ref = "demo-pr"` | `run_id`, `mission_control_url` |
| `get_run_status` | `run_id` | `status`, `phase`, `verdict`, `untouched_consumers` |

### Executor (127.0.0.1:8002) — backend only

`POST /apply`, header `X-Internal-Key`, body `{ "run_id", "approval_id" }`. Steps, in order; any failure stops the sequence:

1. Take the work-tree lock (exclusive file lock on `WORK_ROOT/.changeguard.lock`).
2. Verify the marker and `repo_id`; verify `git rev-parse HEAD == run.head_commit`; verify `git status --porcelain -- src` is empty.
3. `GET /internal/approvals/:id`; refuse unless same run, unused, unexpired, `approval.head_commit == HEAD`, and `sha256(stored diff bytes) == approval.sha256`.
4. `POST /internal/approvals/:id/consume`; refuse unless exactly one row changed.
5. `git apply --check`, then `git apply` of the stored bytes.
6. Full suite with the generated-test limits (§9), all test files included; record `exit_code`.
7. Fresh rule scan of the patched tree; `scan_ok` = scanner exit 0 and every file parsed; `scan_tree` = `git write-tree` hash after `git add -A -- src tests` in a temporary index.
8. Post `reverify_report`; release the lock; return the payload.

No automatic rollback. If anything fails after step 5, the run is `failed`, the evidence says so, and the checkout must be reset.

## 7. Hazards and severities

All static results are **hypotheses** until a valid proof confirms them.

| Hazard | Signal | Severity |
| --- | --- | --- |
| `null-deref` | changed field followed by a plain method call (`.discountCode.toUpperCase(`), with no guard on that line (`?.`, `field ?`, `field &&`, `!= null`, `!== null`) | Critical |
| `event-contract-split` | producer and consumer of one event declare the same field with different types | High |
| `unchecked-json-cast` | `JSON.parse(...) as T` with no runtime validation | Medium |

The rule pack was written for this TypeScript event pattern. Disclose that.

Reference fix (what a correct proposal looks like; the agent writes its own):

```diff
--- a/src/billing/InvoiceLine.ts
+++ b/src/billing/InvoiceLine.ts
-  discountCode: string; // billing's own copy of the contract
+  discountCode: string | null; // billing's own copy of the contract
--- a/src/billing/InvoiceTaxCalculator.ts
+++ b/src/billing/InvoiceTaxCalculator.ts
-  const promoTag = line.discountCode.toUpperCase(); // keep on line 8
+  const promoTag = line.discountCode?.toUpperCase() ?? 'NONE'; // keep on line 8
```

## 8. Proof, risk closure and verdict

```python
proof_valid = (
    collected_and_setup_ok        # suite collected; no compile, import, setup error; no timeout
    and failed >= 1
    and path_reached              # every file in the recorded path executed at least one statement
    and (
        (failure_kind == "thrown" and top_src_frame == hazard_location_of_a_critical_finding)
        or failure_kind == "assertion"
    )
)
proof_status = "VALID" if proof_valid else "INCONCLUSIVE"
```

**Linking.** A finding is linked to a valid proof test when the finding's file is in that test's recorded path.

**Closure.** A Critical or High finding is closed only when **both** hold:
1. a linked valid-proof test passes in the re-verify run (the post-fix control), and
2. the fresh post-apply scan succeeded (`scan_ok`) on the applied tree and no longer reports the finding.

A failed, missing or stale scan closes nothing. Unlinked Critical or High findings stay open.

```python
def compute_verdict(run) -> str:
    b = run.baseline                                   # must exist
    proofs = [t.name for t in run.red_proofs if t.proof_valid]
    r = run.reverify
    if r is not None:
        if (b.exit_code == 0 and b.failed == 0
                and r.exit_code == 0 and r.failed == 0
                and proofs and all(r.result(n) == "passed" for n in proofs)
                and r.total == b.total + len(proofs)
                and r.scan_ok
                and open_critical_high(run) == 0):
            return "PASSED"
        if any(r.result(n) == "failed" for n in proofs):
            return "BLOCKED"
        return "NEEDS_REVIEW"
    if any(t.proof_valid for t in run.red_proofs):
        return "BLOCKED"
    return "NEEDS_REVIEW"
```

`r.result(name)` is `"passed"` only if `per_test` has at least one entry with `file == "tests/generated/<name>.test.ts"` and all such entries passed; `"failed"` if any failed; otherwise `"missing"`.

Reason codes: `BASELINE_GREEN`, `FULL_SUITE_GREEN`, `PROOF_TESTS_PASS`, `TOTALS_MATCH`, `SCAN_OK`, `NO_OPEN_CRITICAL_HIGH`, `VALID_PROOF_FAILING`, `PROOF_TEST_MISSING`, `SCAN_FAILED`, `BASELINE_NOT_GREEN`, `NO_VALID_PROOF`, `REQUIRED_CHECK_FAILED`.

## 9. Generated-test execution limits

Generated tests run in `WORK_ROOT` with `jest.sandbox.config.js`:
- `maxWorkers: 1`, `testTimeout: 30000`, process wall-clock limit 60 s.
- Environment scrubbed to `PATH`, `HOME=<tmp>`, `NODE_ENV=test`, `CI=1`. No credentials.
- `setupFiles: ['<rootDir>/.changeguard/block-io.js']`, which makes `net`, `http`, `https`, `dgram`, `child_process` and `worker_threads` throw on use.
- This is an application-level guard, not an OS sandbox. If Docker is available, the optional hardening is `docker run --network none --read-only -v WORK_ROOT:/work`. Disclose which one was used.

## 10. Approval binding

An approval binds: `run_id`, `proposal_id`, full `sha256` of the stored diff bytes, `head_commit`, `approver_name` (a demo record, not authenticated identity), `created_at`, `expires_at` (+10 min), `used`. The browser sends the full hash it displayed; the backend refuses a mismatch.

## 11. Replay

Replay is a separate read-only stream (`GET /api/replay/:id`) of stored events. It never calls a mutating endpoint. Mutating endpoints ignore all client headers about replay; they refuse anything not allowed by stored run state (approve only when `status = awaiting_approval` and `is_replay = 0`). Tests send missing and spoofed headers to prove this.

## 12. Backend API

Public: `POST /api/runs`, `GET /api/runs/:id`, `GET /api/runs/:id/stream`, `POST /api/runs/:id/approve` (`approver_name`, `proposal_id`, `sha256`), `POST /api/runs/:id/reject` (`approver_name`, `reason`), `GET /api/runs/:id/report?format=json|md`, `POST /api/demo/reset`, `GET /api/replay/:id`.

Internal (127.0.0.1, `X-Internal-Key`): `POST /internal/runs/:id/events`, `POST /internal/runs/:id/proposals`, `GET /internal/approvals/:id`, `POST /internal/approvals/:id/consume`.

Error shape:

```json
{ "error": { "code": "APPROVAL_HASH_MISMATCH", "message": "Stored proposal does not match approved hash.", "retryable": false } }
```

Codes and HTTP status: `NOT_FOUND` 404, `APPROVAL_USED` 409, `APPROVAL_EXPIRED` 410, `APPROVAL_WRONG_RUN` 409, `APPROVAL_HASH_MISMATCH` 409, `HEAD_CHANGED` 409, `WORKTREE_DIRTY` 409, `INVALID_STATE` 409, `PATCH_CHECK_FAILED` 422, `UNAUTHORIZED` 401, `PATH_NOT_ALLOWED` 400, `NOT_DISPOSABLE` 400, `LOCKED` 423, `EVIDENCE_WRITE_FAILED` 502.

## 13. Orchestrate messages

Analysis (backend → `changeguard_analyst`), exactly:

```text
RUN_ID=<run_id>
REQUIREMENT=<requirement text>
BASE_REF=demo-base
HEAD_REF=demo-pr
```

Final reply: `{"run_id":"","phase":"analysis_done","proposal_id":""}` or `{"run_id":"","phase":"no_proof"}`. The backend trusts the database, not the reply's `proposal_id`. Approval never goes to Orchestrate.

## 14. Disclosure (shown in the report and the pitch)

- The fixture is intentionally seeded.
- The rule pack targets this TypeScript event-contract pattern.
- The agent is instructed to test through the changed producer entry point and assert on the billing consumer.
- Reviewer identity is a typed name, not authentication.
- Generated tests run under the limits in §9 (state which variant).
- PASSED describes the tests and scans recorded in this run. It is not a guarantee that a merge is safe.

---

## Version notes

- v1 (elapsed hour 9): initial freeze.
