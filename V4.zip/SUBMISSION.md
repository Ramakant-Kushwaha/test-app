# SUBMISSION.md — pitch, submission copy and judge Q&A

**Owner:** Person A. Fill every `<placeholder>` from `docs/evidence/08/rehearsal.md` and the report before uploading. Delete any line you can't back with evidence.

---

## One-line pitch

A green pipeline proves the tests you already have. ChangeGuard proves, with an executable test, whether a change breaks the code your tests never reached, and applies a fix only after a person approves the exact diff.

## Problem

A change can pass every existing test and still break a downstream consumer. It happens when the change alters a data contract that crosses a boundary the compiler can't see, such as a JSON event, and no existing test sends the new value across it. Reviewers see a green build and a small diff, so the break reaches production.

## Solution

ChangeGuard takes a requirement and a candidate change, and:

1. traces the changed field through imports and events to untouched consumers;
2. writes a requirement-specific regression test that drives the real path, from the changed producer through the event to the consumer;
3. runs it and accepts the failure as proof only if setup succeeded, the whole path executed, and the failure happened at the flagged line (otherwise it reports INCONCLUSIVE);
4. proposes the smallest fix and stores the exact bytes and their SHA-256;
5. applies that diff only after a person approves the displayed hash, once, on the recorded commit;
6. reruns the full suite and a fresh scan, and the backend, not a model, records the verdict.

## What the demo shows (seeded scenario, disclosed)

- **Candidate:** PRICE-142 makes `discountCode` nullable in 3 files. Baseline: `<b_passed>` passed, `<b_failed>` failed, exit `<b_exit>` on commit `<head_commit>`.
- **Path:** `ProductController` → `BillingWebhookAdapter` → event `billing.line` → `BillingConsumer` → `InvoiceTaxCalculator`, which the PR never touched and which keeps its own older copy of the type.
- **Proof:** the generated test fails with a `TypeError` at `InvoiceTaxCalculator.ts:8`; every file on the path executed; status VALID. On the base revision, the same test shows null never reached billing.
- **Approval:** a 2-file diff, full hash shown, approved once.
- **Re-verify:** `<f_passed>` passed, 0 failed, exit 0; the proof test passes; the fresh scan no longer reports the findings. Verdict: PASSED — within tested scope.
- **Measured:** median `<median>` s to BLOCKED over `<n>` runs; `<clean>/<total>` clean rehearsal runs.

## Technology (keep only what you actually used and verified)

- **IBM Bob:** the developer's entry point (ChangeGuard Reviewer mode, starting and watching runs over MCP) and the build tool (Plan → Agent for the fixture, tools, backend and UI; sessions in `docs/evidence/bob/`).
- **IBM watsonx Orchestrate:** the `changeguard_analyst` agent (or supervisor + 4 specialists, if used) coordinates the analysis through an imported MCP toolkit of 5 deterministic tools.
- **Deterministic tools (Python, FastMCP):** git diff, import and event graph, rule pack, Jest runner with proof classification, patch validation; a separate executor reachable only by the backend.
- **Backend (Node, Express, SQLite):** evidence store, approval binding, verdict computation, SSE, report.
- **Mission Control (Angular):** one screen with the live evidence.
- **Target fixture:** Node 20, strict TypeScript, Jest.

## Innovation

The connected chain: a change-specific, cross-boundary hypothesis becomes an executable proof through the real event path, then a hash-bound, single-use human approval, then a full rerun and a computed verdict. Models propose; tools execute; the backend decides. We don't claim no other tool can do parts of this; we show the whole chain working, with evidence at every step.

## Impact (only measured claims)

- One seeded cross-boundary regression proven before merge, with a fix approved and verified, in `<median>` s median analysis time (n = `<n>`).
- One reviewer trial (anecdotal, n = 1): `<minutes>` minutes, found: `<yes/no>`.

## Limitations

- One intentionally seeded TypeScript scenario; the rule pack targets this event-contract pattern.
- The agent is instructed to test through the changed producer entry point.
- Reviewer identity is a typed name, not authentication.
- Generated tests run with application-level limits (`<variant>`), not a full OS sandbox.
- PASSED describes the recorded tests and scans in this run. It doesn't guarantee a merge is safe.

## Three-minute script

| Time | On screen | Say |
| --- | --- | --- |
| 0:00–0:15 | Bob: "Is PRICE-142 safe to merge?" → run starts; click the link | "CI is green on this branch. Bob just started ChangeGuard to check what those tests never exercised. This scenario is seeded so you can see every step." |
| 0:15–0:40 | Mission Control: baseline counts and exit code; phases moving | "Bob hands the analysis to watsonx Orchestrate. Every action on the repository goes through deterministic tools, and every result is stored as evidence." |
| 0:40–1:05 | Path drawn through the dashed `billing.line` edge to the red billing node; click it | "The PR never touched billing. Billing keeps an older copy of this contract and calls toUpperCase on a field that can now be null. The compiler can't see that link. So far, that's a hypothesis." |
| 1:05–1:35 | Live evidence: TypeError at line 8; path files all ✓; VALID PROOF; BLOCKED | "The agent drove a real request through the controller, the event and billing. Setup succeeded, the whole path ran, and it failed exactly at the flagged line. That's proof. Verdict: BLOCKED, after `<time>` seconds." |
| 1:35–2:05 | Proposal drawer: 2-file diff, full hash; type name; approve | "The model proposed this fix but can't apply it. I approve these exact bytes on this commit, once." |
| 2:05–2:30 | Re-verify: full counts, exit 0, proof test passed, fresh scan ok; PASSED — within tested scope | "Full suite rerun, the same test now passes, and the scan is clean. The backend set PASSED, within the scope of what we tested." |
| 2:30–3:00 | Report: verdict history, metrics with n, limitations | "Every claim links to stored evidence, including what we didn't prove. A green pipeline proves the tests you have; ChangeGuard proves the failure you missed." |

Operator cues: if analysis is still running at 1:00, keep explaining the contract split. If a live step fails, say so in one sentence and switch to the labelled replay. Stop after the closing line.

## Judge questions

| Question | Answer |
| --- | --- |
| Is the example planted? | Yes, and we say so. It demonstrates the workflow with real commands and real outputs, not general accuracy. |
| Isn't this regex plus an LLM? | Static rules nominate hypotheses. Only an executed test that runs the whole path and fails at the flagged line counts as proof; anything else is INCONCLUSIVE. |
| What if the test fails because of an import error? | It's INCONCLUSIVE, shown on screen, and can't produce BLOCKED. |
| How do you know the event carried the value? | The test calls the producer, not billing; coverage shows every path file executed; the stack goes through the consumer. On the base revision, null never reaches billing. |
| Can the agent apply a different patch? | No. Agents can only propose. The executor applies the stored bytes whose hash the reviewer approved, on the recorded commit, once; changed bytes, a moved HEAD, an expired or reused approval are all refused. |
| What stops a fake PASSED? | The backend computes it: baseline green, full rerun green, the proof test present and passing, totals matching, a fresh successful scan, and no open Critical or High finding. Delete the test and PASSED is impossible. |
| Does PASSED mean safe to merge? | No. It means the recorded tests and scans passed within this run. |
| Why IBM Bob? | It's where the developer asks the question, and it built the system with Plan then Agent mode; sessions are in the repo. |
| Why watsonx Orchestrate? | It coordinates the analysis and the tool calls; deterministic tools and the backend enforce evidence and control. |
| What if IBM services fail during judging? | We say so and play a labelled recording of a verified run, if the rules allow. We never present it as live. |
| What's your proof of value? | Measured times over `<n>` runs and one disclosed reviewer trial. Nothing else is claimed. |

## Upload checklist

- [ ] Every placeholder replaced or the line deleted.
- [ ] Problem, Solution, Technology, Innovation, Impact and Limitations pasted into the platform's fields.
- [ ] Video uploaded and playback tested; repository link works; README links Bob evidence.
- [ ] Uploaded at least 3 hours before the confirmed cutoff.
