# AGENTS.md — rules for every task in this workspace

You are helping a four-person team build ChangeGuard AI for a hackathon (deadline to be confirmed on the submission platform). One seeded demo story, built to be repeatable and honest.

## Read first

- `plans/CONTRACTS.md` holds the frozen interfaces. Never rename a stage key, tool, argument, table, column, route or event field from it. If a task seems to need a change, stop and say so instead.
- The plan file you were given lists the files you may create or change. Stay inside it.

## Workflow

- In Plan mode: list every file you will create or change, every command you will run, and how each acceptance check will be met. Wait for approval.
- In Agent mode: implement only the approved plan. Run the acceptance checks at the end and show their output.

## Hard rules

1. `target-enterprise-app/` is the fixture: change it only in plan-02. All runtime work happens in the disposable checkout `demo-work/`, and only the executor may write to `demo-work/src/`. Never run `git reset`, `git clean` or delete files in any directory that lacks the `.changeguard-disposable` marker.
2. Never put credentials, API keys, tunnel URLs or machine-specific absolute paths in committed files. Use environment variables and `.env.example`.
3. Python subprocess calls: argument lists, `shell=False`, a 120-second timeout, output capped at 64 KB.
4. Every tool writes its evidence event before returning. If the evidence write fails, the tool fails.
5. No model output decides a verdict. The backend computes it from evidence rows.
6. No hard-coded demo values in the UI. Everything comes from the API.
7. No new features, dependencies or "nice to have" extras beyond the plan.
8. Keep files small and readable. Add a unit test for every rule in `CONTRACTS.md` that your code implements.
9. Show real counts and exit codes. Never display a total as a passed count, and never describe PASSED as "safe to merge".
10. Static findings are hypotheses. Only a VALID proof confirms a regression; anything else is INCONCLUSIVE.

## Repository layout

```text
changeguard-workspace/
├── AGENTS.md
├── plans/                       # these plan files
├── .bob/mcp.json                # no secrets
├── target-enterprise-app/       # fixture repo, never changed at runtime (plan-02)
├── demo-work/                   # disposable checkout with .changeguard-disposable (plan-02 script)
└── changeguard-ai/
    ├── tools/                   # plan-03
    ├── wxo-agents/              # plan-04
    ├── backend/                 # plan-05
    ├── frontend/                # plan-06
    ├── scripts/                 # plan-08
    └── docs/evidence/           # command output per plan
```
